"use client"

import type React from "react"

import { useState } from "react"
import { useRouter } from "next/navigation"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { RadioGroup, RadioGroupItem } from "@/components/ui/radio-group"
import { Separator } from "@/components/ui/separator"
import { CreditCard, Lock, Bitcoin, Copy, AlertTriangle } from "lucide-react"
import { CardElement, useStripe, useElements, Elements } from "@stripe/react-stripe-js"
import { loadStripe } from "@stripe/stripe-js"

// This would be your actual Stripe publishable key in a real app
// For this prototype, we're using a placeholder
const stripePromise = loadStripe("pk_test_placeholder")

interface PaymentFormProps {
  listingId: string
  amount: number
}

function PaymentFormContent({ listingId, amount }: PaymentFormProps) {
  const router = useRouter()
  const stripe = useStripe()
  const elements = useElements()

  const [paymentMethod, setPaymentMethod] = useState("card")
  const [isProcessing, setIsProcessing] = useState(false)
  const [errorMessage, setErrorMessage] = useState<string | null>(null)
  const [txHash, setTxHash] = useState("")

  // In a real app, this would be fetched from the seller's profile
  const sellerUSDTAddress = "0x742d35Cc6634C0532925a3b844Bc454e4438f44e"

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault()

    if (paymentMethod === "card") {
      if (!stripe || !elements) {
        // Stripe.js has not loaded yet
        return
      }

      setIsProcessing(true)
      setErrorMessage(null)

      try {
        // In a real implementation, you would:
        // 1. Create a payment intent on your server
        // 2. Confirm the payment with stripe.confirmCardPayment
        // 3. Handle the result

        // For this prototype, we'll simulate a successful payment
        setTimeout(() => {
          setIsProcessing(false)
          router.push("/checkout/success")
        }, 2000)
      } catch (err) {
        setErrorMessage("An unexpected error occurred")
        setIsProcessing(false)
      }
    } else if (paymentMethod === "crypto") {
      // For crypto payments, we need to verify the transaction manually
      if (!txHash.trim()) {
        setErrorMessage("Please enter the transaction hash")
        return
      }

      setIsProcessing(true)
      setErrorMessage(null)

      try {
        // In a real implementation, you would:
        // 1. Submit the transaction hash to your server
        // 2. Verify the transaction on the blockchain
        // 3. Confirm the payment amount matches

        // For this prototype, we'll simulate verification
        setTimeout(() => {
          setIsProcessing(false)
          router.push("/checkout/success?method=crypto")
        }, 2000)
      } catch (err) {
        setErrorMessage("Failed to verify transaction")
        setIsProcessing(false)
      }
    }
  }

  return (
    <form onSubmit={handleSubmit} className="space-y-6">
      <RadioGroup defaultValue="card" value={paymentMethod} onValueChange={setPaymentMethod}>
        <div className="flex items-center space-x-2">
          <RadioGroupItem value="card" id="card" />
          <Label htmlFor="card" className="flex items-center gap-2">
            <CreditCard className="h-4 w-4" />
            Credit or Debit Card
          </Label>
        </div>
        <div className="flex items-center space-x-2">
          <RadioGroupItem value="crypto" id="crypto" />
          <Label htmlFor="crypto" className="flex items-center gap-2">
            <Bitcoin className="h-4 w-4" />
            Cryptocurrency (USDT)
          </Label>
        </div>
      </RadioGroup>

      {paymentMethod === "card" && (
        <div className="space-y-4">
          <div className="grid gap-4 md:grid-cols-2">
            <div className="space-y-2">
              <Label htmlFor="name">Name on Card</Label>
              <Input id="name" placeholder="John Doe" required />
            </div>
            <div className="space-y-2">
              <Label htmlFor="email">Email</Label>
              <Input id="email" type="email" placeholder="john@example.com" required />
            </div>
          </div>

          <div className="space-y-2">
            <Label>Card Information</Label>
            <div className="rounded-md border p-3">
              <CardElement
                options={{
                  style: {
                    base: {
                      fontSize: "16px",
                      color: "#424770",
                      "::placeholder": {
                        color: "#aab7c4",
                      },
                    },
                    invalid: {
                      color: "#9e2146",
                    },
                  },
                }}
              />
            </div>
            <div className="flex items-center gap-1 text-xs text-muted-foreground">
              <Lock className="h-3 w-3" />
              <span>Your card information is secure and encrypted</span>
            </div>
          </div>
        </div>
      )}

      {paymentMethod === "crypto" && (
        <div className="space-y-4">
          <div className="rounded-md border p-4 bg-muted/50">
            <div className="space-y-4">
              <div>
                <h3 className="text-sm font-medium">Pay with USDT (Tether)</h3>
                <p className="text-xs text-muted-foreground mt-1">
                  Send exactly {amount.toFixed(2)} USDT to the seller's address below
                </p>
              </div>

              <div className="space-y-2">
                <Label className="text-xs text-muted-foreground">Seller's USDT Address (ERC-20)</Label>
                <div className="flex items-center gap-2">
                  <Input value={sellerUSDTAddress} readOnly className="font-mono text-sm" />
                  <Button
                    type="button"
                    variant="outline"
                    size="sm"
                    className="shrink-0"
                    onClick={() => {
                      navigator.clipboard.writeText(sellerUSDTAddress)
                    }}
                  >
                    <Copy className="h-4 w-4" />
                  </Button>
                </div>
              </div>

              <div className="space-y-2">
                <Label htmlFor="txHash">Transaction Hash</Label>
                <Input
                  id="txHash"
                  placeholder="0x..."
                  value={txHash}
                  onChange={(e) => setTxHash(e.target.value)}
                  className="font-mono"
                  required
                />
                <p className="text-xs text-muted-foreground">
                  After sending the payment, paste the transaction hash here for verification
                </p>
              </div>

              <div className="rounded-md bg-amber-50 p-3 dark:bg-amber-950/50">
                <div className="flex items-start gap-2">
                  <AlertTriangle className="h-4 w-4 text-amber-600 mt-0.5 dark:text-amber-400" />
                  <div className="text-xs text-amber-600 dark:text-amber-400">
                    <p className="font-medium">Important</p>
                    <ul className="list-disc list-inside mt-1 space-y-1">
                      <li>Send only USDT on the Ethereum network (ERC-20)</li>
                      <li>Double-check the address before sending</li>
                      <li>Include the exact amount to ensure proper verification</li>
                    </ul>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      )}

      {errorMessage && <div className="rounded-md bg-destructive/10 p-3 text-sm text-destructive">{errorMessage}</div>}

      <Separator />

      <Button type="submit" className="w-full" size="lg" disabled={isProcessing}>
        {isProcessing
          ? "Processing..."
          : paymentMethod === "card"
            ? `Pay $${amount.toFixed(2)}`
            : `Verify USDT Payment`}
      </Button>
    </form>
  )
}

export default function PaymentForm({ listingId, amount }: PaymentFormProps) {
  return (
    <Elements stripe={stripePromise}>
      <PaymentFormContent listingId={listingId} amount={amount} />
    </Elements>
  )
}

