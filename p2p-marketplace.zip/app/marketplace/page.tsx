import { Filter, LayoutGrid, List, Search } from "lucide-react"
import Link from "next/link"
import MarketplaceFilters from "@/components/marketplace/marketplace-filters"
import ListingCard from "@/components/marketplace/listing-card"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"

export default function MarketplacePage() {
  return (
    <div className="flex min-h-screen flex-col">
      <div className="bg-muted py-6">
        <div className="container px-4 md:px-6">
          <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-4 items-center">
            <div className="col-span-2 lg:col-span-3">
              <div className="relative">
                <Search className="absolute left-2.5 top-2.5 h-4 w-4 text-muted-foreground" />
                <Input
                  type="search"
                  placeholder="Search services, digital assets, or sellers..."
                  className="w-full bg-background pl-8 shadow-none border-border"
                />
              </div>
            </div>
            <div className="flex space-x-2 col-span-2 lg:col-span-1 lg:justify-end">
              <Button variant="outline" size="sm">
                <Filter className="mr-2 h-4 w-4" />
                Filters
              </Button>
              <Button variant="default" size="sm">
                <Link href="/create-listing">Create Listing</Link>
              </Button>
            </div>
          </div>
        </div>
      </div>

      <div className="container px-4 py-6 md:px-6 md:py-8">
        <Tabs defaultValue="all" className="w-full">
          <div className="flex items-center justify-between">
            <TabsList>
              <TabsTrigger value="all">All Listings</TabsTrigger>
              <TabsTrigger value="services">Services</TabsTrigger>
              <TabsTrigger value="digitalAssets">Digital Assets</TabsTrigger>
            </TabsList>
            <div className="flex items-center gap-2">
              <Button variant="outline" size="sm" className="hidden md:flex">
                <LayoutGrid className="h-4 w-4" />
                <span className="sr-only">Grid view</span>
              </Button>
              <Button variant="outline" size="sm" className="hidden md:flex">
                <List className="h-4 w-4" />
                <span className="sr-only">List view</span>
              </Button>
              <Button variant="outline" size="sm">
                Sort by: Recommended <Filter className="ml-2 h-4 w-4" />
              </Button>
            </div>
          </div>

          <div className="mt-6 grid grid-cols-1 gap-6 md:grid-cols-12">
            <div className="hidden md:block md:col-span-3">
              <MarketplaceFilters />
            </div>

            <div className="md:col-span-9">
              <TabsContent value="all" className="mt-0">
                <div className="grid grid-cols-1 gap-6 sm:grid-cols-2 lg:grid-cols-3">
                  {listings.map((listing) => (
                    <ListingCard key={listing.id} listing={listing} />
                  ))}
                </div>
              </TabsContent>
              <TabsContent value="services" className="mt-0">
                <div className="grid grid-cols-1 gap-6 sm:grid-cols-2 lg:grid-cols-3">
                  {listings
                    .filter((listing) => listing.type === "service")
                    .map((listing) => (
                      <ListingCard key={listing.id} listing={listing} />
                    ))}
                </div>
              </TabsContent>
              <TabsContent value="digitalAssets" className="mt-0">
                <div className="grid grid-cols-1 gap-6 sm:grid-cols-2 lg:grid-cols-3">
                  {listings
                    .filter((listing) => listing.type === "digital")
                    .map((listing) => (
                      <ListingCard key={listing.id} listing={listing} />
                    ))}
                </div>
              </TabsContent>
            </div>
          </div>
        </Tabs>
      </div>
    </div>
  )
}

const listings = [
  {
    id: "1",
    title: "Professional Logo Design",
    description: "I will create a modern, memorable logo for your brand with unlimited revisions",
    price: 120,
    rating: 4.9,
    reviewCount: 142,
    image: "/placeholder.svg?height=200&width=300",
    seller: {
      name: "Alex Morgan",
      avatar: "/placeholder.svg?height=40&width=40",
      verifiedSeller: true,
    },
    type: "service",
    category: "Design",
    deliveryTime: "3 days",
    blockchain: {
      verified: true,
      transactionId: "0x8fe72a3...",
    },
  },
  {
    id: "2",
    title: "Complete Social Media Strategy Pack",
    description: "Digital asset pack with templates, guides, and calendars for social media marketing",
    price: 49,
    rating: 4.7,
    reviewCount: 89,
    image: "/placeholder.svg?height=200&width=300",
    seller: {
      name: "Sarah Johnson",
      avatar: "/placeholder.svg?height=40&width=40",
      verifiedSeller: true,
    },
    type: "digital",
    category: "Marketing",
    blockchain: {
      verified: true,
      transactionId: "0x7ad92b4...",
    },
  },
  {
    id: "3",
    title: "Website Development - Full Stack",
    description: "Custom website development with responsive design and backend integration",
    price: 600,
    rating: 4.8,
    reviewCount: 64,
    image: "/placeholder.svg?height=200&width=300",
    seller: {
      name: "Raj Patel",
      avatar: "/placeholder.svg?height=40&width=40",
      verifiedSeller: true,
    },
    type: "service",
    category: "Development",
    deliveryTime: "14 days",
    blockchain: {
      verified: true,
      transactionId: "0x3fe18c2...",
    },
  },
  {
    id: "4",
    title: "UI/UX Design System",
    description: "Complete Figma design system with components, styles, and documentation",
    price: 79,
    rating: 4.9,
    reviewCount: 37,
    image: "/placeholder.svg?height=200&width=300",
    seller: {
      name: "Elena Kim",
      avatar: "/placeholder.svg?height=40&width=40",
      verifiedSeller: true,
    },
    type: "digital",
    category: "Design",
    blockchain: {
      verified: true,
      transactionId: "0x2cd45a9...",
    },
  },
  {
    id: "5",
    title: "SEO Optimization Service",
    description: "I will optimize your website for search engines with keyword research and implementation",
    price: 250,
    rating: 4.6,
    reviewCount: 52,
    image: "/placeholder.svg?height=200&width=300",
    seller: {
      name: "Tom Wilson",
      avatar: "/placeholder.svg?height=40&width=40",
      verifiedSeller: true,
    },
    type: "service",
    category: "Marketing",
    deliveryTime: "7 days",
    blockchain: {
      verified: true,
      transactionId: "0x9ab23d1...",
    },
  },
  {
    id: "6",
    title: "Photography Lightroom Presets",
    description: "Professional Lightroom presets for portrait, landscape, and product photography",
    price: 35,
    rating: 4.8,
    reviewCount: 116,
    image: "/placeholder.svg?height=200&width=300",
    seller: {
      name: "Mia Rodriguez",
      avatar: "/placeholder.svg?height=40&width=40",
      verifiedSeller: true,
    },
    type: "digital",
    category: "Photography",
    blockchain: {
      verified: true,
      transactionId: "0x5ef92c6...",
    },
  },
]

