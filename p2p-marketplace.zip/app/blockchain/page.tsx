import Link from "next/link"
import Image from "next/image"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { ArrowRight, CheckCircle2, FileText, Lock, Search, Shield } from "lucide-react"

export default function BlockchainPage() {
  return (
    <div className="container px-4 py-8 md:px-6 md:py-12">
      <div className="mx-auto max-w-3xl space-y-4 text-center">
        <h1 className="text-3xl font-bold tracking-tight sm:text-4xl md:text-5xl">Blockchain Verification</h1>
        <p className="text-muted-foreground md:text-xl">
          Our marketplace uses blockchain technology to verify transactions, reviews, and user activities, ensuring
          transparency and trust.
        </p>
        <div className="flex flex-col justify-center gap-4 sm:flex-row">
          <Button asChild size="lg">
            <Link href="/blockchain/scanner">
              <Search className="mr-2 h-4 w-4" />
              Explore Blockchain Scanner
            </Link>
          </Button>
          <Button variant="outline" asChild size="lg">
            <Link href="/how-it-works">
              Learn More
              <ArrowRight className="ml-2 h-4 w-4" />
            </Link>
          </Button>
        </div>
      </div>

      <div className="mt-16 grid gap-8 md:grid-cols-2 lg:grid-cols-3">
        {features.map((feature, index) => (
          <Card key={index} className="flex flex-col">
            <CardHeader>
              <div className="mb-2 flex h-12 w-12 items-center justify-center rounded-lg bg-primary/10">
                <feature.icon className="h-6 w-6 text-primary" />
              </div>
              <CardTitle>{feature.title}</CardTitle>
              <CardDescription>{feature.description}</CardDescription>
            </CardHeader>
            <CardContent className="flex-1">
              <ul className="space-y-2 text-sm">
                {feature.benefits.map((benefit, i) => (
                  <li key={i} className="flex items-start gap-2">
                    <CheckCircle2 className="mt-0.5 h-4 w-4 text-emerald-500" />
                    <span>{benefit}</span>
                  </li>
                ))}
              </ul>
            </CardContent>
          </Card>
        ))}
      </div>

      <div className="mt-16">
        <Card>
          <CardHeader className="text-center">
            <CardTitle className="text-2xl">How Blockchain Verification Works</CardTitle>
            <CardDescription>
              Our platform uses blockchain technology to create an immutable record of marketplace activities
            </CardDescription>
          </CardHeader>
          <CardContent>
            <div className="grid gap-8 md:grid-cols-2">
              <div className="relative aspect-video overflow-hidden rounded-lg border">
                <Image
                  src="/placeholder.svg?height=300&width=500"
                  alt="Blockchain verification diagram"
                  fill
                  className="object-cover"
                />
              </div>
              <div className="space-y-4">
                <div className="space-y-2">
                  <h3 className="text-lg font-medium">1. Transaction Recording</h3>
                  <p className="text-sm text-muted-foreground">
                    When a marketplace activity occurs (order completion, review submission, etc.), the details are
                    hashed and recorded on the blockchain with a unique transaction ID.
                  </p>
                </div>

                <div className="space-y-2">
                  <h3 className="text-lg font-medium">2. Verification Process</h3>
                  <p className="text-sm text-muted-foreground">
                    The transaction is verified by multiple nodes in the blockchain network, ensuring its authenticity
                    and preventing tampering or fraud.
                  </p>
                </div>

                <div className="space-y-2">
                  <h3 className="text-lg font-medium">3. Immutable Record</h3>
                  <p className="text-sm text-muted-foreground">
                    Once verified, the transaction becomes part of the blockchain's permanent record, creating an
                    immutable history that can be referenced and verified at any time.
                  </p>
                </div>

                <div className="space-y-2">
                  <h3 className="text-lg font-medium">4. Public Verification</h3>
                  <p className="text-sm text-muted-foreground">
                    Anyone can verify the authenticity of marketplace activities through our Blockchain Scanner,
                    providing complete transparency and trust.
                  </p>
                </div>
              </div>
            </div>

            <div className="mt-8 flex justify-center">
              <Button asChild>
                <Link href="/blockchain/scanner">
                  <Search className="mr-2 h-4 w-4" />
                  Try the Blockchain Scanner
                </Link>
              </Button>
            </div>
          </CardContent>
        </Card>
      </div>

      <div className="mt-16">
        <div className="mx-auto max-w-3xl space-y-4 text-center">
          <h2 className="text-3xl font-bold">Frequently Asked Questions</h2>
          <p className="text-muted-foreground">
            Learn more about how we use blockchain technology to enhance trust and transparency
          </p>
        </div>

        <div className="mt-8 grid gap-4 md:grid-cols-2">
          {faqs.map((faq, index) => (
            <Card key={index}>
              <CardHeader>
                <CardTitle className="text-lg">{faq.question}</CardTitle>
              </CardHeader>
              <CardContent>
                <p className="text-sm text-muted-foreground">{faq.answer}</p>
              </CardContent>
            </Card>
          ))}
        </div>
      </div>
    </div>
  )
}

const features = [
  {
    title: "Verified Transactions",
    description: "All marketplace transactions are recorded on blockchain",
    icon: Shield,
    benefits: [
      "Immutable record of all payments and order completions",
      "Escrow payment verification and tracking",
      "Transparent fee structure with blockchain proof",
      "Dispute resolution backed by verifiable evidence",
    ],
  },
  {
    title: "Authentic Reviews",
    description: "Reviews and ratings verified by blockchain technology",
    icon: FileText,
    benefits: [
      "Prevent fake or manipulated reviews",
      "Verify reviewer actually purchased the service/product",
      "Timestamp proof of when reviews were submitted",
      "Build genuine reputation based on verified feedback",
    ],
  },
  {
    title: "Enhanced Security",
    description: "Advanced security through decentralized verification",
    icon: Lock,
    benefits: [
      "Prevent fraudulent activities through blockchain verification",
      "Secure KYC verification with privacy protection",
      "Tamper-proof record of all marketplace activities",
      "Cryptographic security for sensitive transaction data",
    ],
  },
]

const faqs = [
  {
    question: "What blockchain technology does the platform use?",
    answer:
      "Our platform utilizes Ethereum blockchain technology for its robust smart contract capabilities, widespread adoption, and strong security features. This allows us to create verifiable records of marketplace activities while maintaining efficiency and accessibility.",
  },
  {
    question: "Can I verify transactions without technical knowledge?",
    answer:
      "Yes! Our Blockchain Scanner provides a user-friendly interface that allows anyone to verify transactions, reviews, and other marketplace activities without any technical knowledge. Simply search by transaction ID, user, or listing to see the verification details.",
  },
  {
    question: "How does blockchain verification prevent fake reviews?",
    answer:
      "When a user submits a review, it's linked to a verified purchase transaction on the blockchain. This creates an immutable connection between the reviewer and their purchase, making it impossible to create fake reviews without actually using the service or buying the product.",
  },
  {
    question: "Is my personal information stored on the blockchain?",
    answer:
      "No, we prioritize your privacy. Personal information is never stored directly on the blockchain. Instead, we use cryptographic hashing to create references to transactions while keeping your personal data secure and private in our encrypted databases.",
  },
  {
    question: "How does blockchain help with dispute resolution?",
    answer:
      "Blockchain provides an immutable record of all transactions, communications, and deliverables. In case of disputes, this verifiable evidence helps our resolution team make fair decisions based on factual, tamper-proof information rather than conflicting claims.",
  },
  {
    question: "Does blockchain verification slow down transactions?",
    answer:
      "No, our implementation is optimized for efficiency. While blockchain verification occurs in the background, the user experience remains fast and seamless. The verification process typically completes within minutes without impacting your ability to use the marketplace.",
  },
]

