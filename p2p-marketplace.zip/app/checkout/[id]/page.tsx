import Link from "next/link"
import Image from "next/image"
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card"
import { Separator } from "@/components/ui/separator"
import { Badge } from "@/components/ui/badge"
import { ArrowLeft, Calendar, CheckCircle, Clock, Lock, Shield } from "lucide-react"
import PaymentForm from "@/components/payment/payment-form"

export default function CheckoutPage({ params }: { params: { id: string } }) {
  // In a real app, we would fetch the listing data based on the ID
  // For this prototype, we'll use mock data
  const listing = {
    id: params.id,
    title: "Professional Logo Design",
    description: "I will create a modern, memorable logo for your brand with unlimited revisions",
    price: 120,
    serviceFee: 12,
    total: 132,
    image: "/placeholder.svg?height=200&width=300",
    deliveryTime: "3 days",
    seller: {
      id: "seller1",
      name: "Alex Morgan",
      avatar: "/placeholder.svg?height=40&width=40",
      verifiedSeller: true,
    },
  }

  return (
    <div className="container px-4 py-8 md:px-6 md:py-12">
      <div className="mb-6">
        <Link
          href={`/marketplace/${listing.id}`}
          className="flex items-center text-sm text-muted-foreground hover:text-foreground"
        >
          <ArrowLeft className="mr-2 h-4 w-4" />
          Back to listing
        </Link>
      </div>

      <div className="grid gap-8 md:grid-cols-12">
        <div className="md:col-span-7 lg:col-span-8">
          <div className="space-y-8">
            <div>
              <h1 className="text-3xl font-bold">Checkout</h1>
              <p className="text-muted-foreground">Complete your purchase securely</p>
            </div>

            <Card>
              <CardHeader>
                <CardTitle>Payment Method</CardTitle>
                <CardDescription>All transactions are secure and encrypted</CardDescription>
              </CardHeader>
              <CardContent>
                <PaymentForm listingId={listing.id} amount={listing.total} />
              </CardContent>
              <CardFooter className="flex flex-col space-y-4 border-t bg-muted/50 px-6 py-4">
                <div className="flex items-start gap-2 text-sm">
                  <Lock className="mt-0.5 h-4 w-4 text-muted-foreground" />
                  <div>
                    <p className="font-medium">Secure Payment Processing</p>
                    <p className="text-muted-foreground">
                      Your payment information is encrypted and secure. We never store your full credit card details.
                    </p>
                  </div>
                </div>
                <div className="flex items-start gap-2 text-sm">
                  <Shield className="mt-0.5 h-4 w-4 text-muted-foreground" />
                  <div>
                    <p className="font-medium">Buyer Protection</p>
                    <p className="text-muted-foreground">
                      Your payment is held in escrow until you confirm the work is completed to your satisfaction.
                    </p>
                  </div>
                </div>
              </CardFooter>
            </Card>

            <Card>
              <CardHeader>
                <CardTitle>Payment Flow</CardTitle>
                <CardDescription>How your payment is processed and protected</CardDescription>
              </CardHeader>
              <CardContent>
                <div className="space-y-6">
                  <div className="flex gap-4">
                    <div className="flex h-8 w-8 items-center justify-center rounded-full bg-primary text-primary-foreground">
                      1
                    </div>
                    <div className="flex-1">
                      <h3 className="font-medium">Payment Authorization</h3>
                      <p className="text-sm text-muted-foreground">
                        Your payment is authorized but not charged until the seller accepts your order.
                      </p>
                    </div>
                  </div>
                  <div className="flex gap-4">
                    <div className="flex h-8 w-8 items-center justify-center rounded-full bg-primary text-primary-foreground">
                      2
                    </div>
                    <div className="flex-1">
                      <h3 className="font-medium">Secure Escrow</h3>
                      <p className="text-sm text-muted-foreground">
                        Once the seller accepts, your payment is held in escrow while the work is completed.
                      </p>
                    </div>
                  </div>
                  <div className="flex gap-4">
                    <div className="flex h-8 w-8 items-center justify-center rounded-full bg-primary text-primary-foreground">
                      3
                    </div>
                    <div className="flex-1">
                      <h3 className="font-medium">Order Completion</h3>
                      <p className="text-sm text-muted-foreground">
                        When you approve the completed work, the payment is released to the seller.
                      </p>
                    </div>
                  </div>
                  <div className="flex gap-4">
                    <div className="flex h-8 w-8 items-center justify-center rounded-full bg-primary text-primary-foreground">
                      4
                    </div>
                    <div className="flex-1">
                      <h3 className="font-medium">Blockchain Verification</h3>
                      <p className="text-sm text-muted-foreground">
                        The transaction is recorded on the blockchain for transparency and verification.
                      </p>
                    </div>
                  </div>
                  <div className="flex gap-4">
                    <div className="flex h-8 w-8 items-center justify-center rounded-full bg-primary text-primary-foreground">
                      5
                    </div>
                    <div className="flex-1">
                      <h3 className="font-medium">Cryptocurrency Option</h3>
                      <p className="text-sm text-muted-foreground">
                        You can also pay directly with USDT (Tether) to the seller's wallet address for faster
                        international transactions.
                      </p>
                    </div>
                  </div>
                </div>
              </CardContent>
            </Card>
          </div>
        </div>

        <div className="md:col-span-5 lg:col-span-4">
          <div className="space-y-6">
            <Card>
              <CardHeader>
                <CardTitle>Order Summary</CardTitle>
              </CardHeader>
              <CardContent className="space-y-4">
                <div className="flex gap-4">
                  <div className="relative h-16 w-16 overflow-hidden rounded-md">
                    <Image
                      src={listing.image || "/placeholder.svg"}
                      alt={listing.title}
                      fill
                      className="object-cover"
                    />
                  </div>
                  <div>
                    <h3 className="font-medium">{listing.title}</h3>
                    <div className="mt-1 flex items-center gap-2 text-sm text-muted-foreground">
                      <Clock className="h-3 w-3" />
                      <span>Delivery in {listing.deliveryTime}</span>
                    </div>
                  </div>
                </div>

                <div className="rounded-lg border p-3">
                  <div className="flex items-center gap-2">
                    <div className="relative h-8 w-8 overflow-hidden rounded-full">
                      <Image
                        src={listing.seller.avatar || "/placeholder.svg"}
                        alt={listing.seller.name}
                        fill
                        className="object-cover"
                      />
                    </div>
                    <div>
                      <p className="text-sm font-medium">{listing.seller.name}</p>
                      <div className="flex items-center gap-1">
                        {listing.seller.verifiedSeller && (
                          <Badge
                            variant="outline"
                            className="gap-1 border-emerald-200 bg-emerald-50 text-xs text-emerald-700 dark:border-emerald-800 dark:bg-emerald-950 dark:text-emerald-400"
                          >
                            <Shield className="h-3 w-3" />
                            Verified Seller
                          </Badge>
                        )}
                      </div>
                    </div>
                  </div>
                </div>

                <Separator />

                <div className="space-y-2">
                  <div className="flex justify-between">
                    <span className="text-muted-foreground">Subtotal</span>
                    <span>${listing.price.toFixed(2)}</span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-muted-foreground">Service fee</span>
                    <span>${listing.serviceFee.toFixed(2)}</span>
                  </div>
                  <Separator />
                  <div className="flex justify-between font-medium">
                    <span>Total</span>
                    <span>${listing.total.toFixed(2)}</span>
                  </div>
                </div>

                <div className="rounded-lg bg-muted p-3">
                  <div className="flex items-center gap-2 text-sm">
                    <Calendar className="h-4 w-4 text-muted-foreground" />
                    <div>
                      <span className="font-medium">Estimated Delivery</span>
                      <p className="text-muted-foreground">
                        {new Date(Date.now() + 3 * 24 * 60 * 60 * 1000).toLocaleDateString("en-US", {
                          weekday: "long",
                          month: "long",
                          day: "numeric",
                        })}
                      </p>
                    </div>
                  </div>
                </div>
              </CardContent>
            </Card>

            <Card>
              <CardContent className="p-4">
                <div className="flex items-center gap-2 text-sm">
                  <CheckCircle className="h-4 w-4 text-emerald-500" />
                  <span>Money-back guarantee</span>
                </div>
                <div className="flex items-center gap-2 text-sm">
                  <CheckCircle className="h-4 w-4 text-emerald-500" />
                  <span>Secure payment processing</span>
                </div>
                <div className="flex items-center gap-2 text-sm">
                  <CheckCircle className="h-4 w-4 text-emerald-500" />
                  <span>Blockchain verified transaction</span>
                </div>
              </CardContent>
            </Card>

            <div className="text-center text-xs text-muted-foreground">
              By completing this purchase, you agree to our{" "}
              <Link href="/terms" className="underline underline-offset-2 hover:text-foreground">
                Terms of Service
              </Link>{" "}
              and{" "}
              <Link href="/privacy" className="underline underline-offset-2 hover:text-foreground">
                Privacy Policy
              </Link>
            </div>
          </div>
        </div>
      </div>
    </div>
  )
}

