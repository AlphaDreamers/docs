import Image from "next/image"
import { Button } from "@/components/ui/button"
import { Card, CardContent } from "@/components/ui/card"
import { Star, ThumbsDown, ThumbsUp, Shield, ExternalLink } from "lucide-react"

export default function ReviewsList({ listingId, reviewCount, rating }) {
  // This would be fetched from an API in a real application
  const reviews = [
    {
      id: 1,
      user: {
        name: "Emma Watson",
        avatar: "/placeholder.svg?height=40&width=40",
      },
      rating: 5,
      date: "2023-02-15",
      content:
        "Amazing service! The designer was very professional and delivered exactly what I needed for my brand. Quick turnaround time and excellent communication throughout the process.",
      helpful: 24,
      notHelpful: 2,
      blockchain: {
        verified: true,
        transactionId: "0x7ae92b4c6e8d9f0a1b2c3d4e5f6a7b8c9d0e1f2a",
      },
    },
    {
      id: 2,
      user: {
        name: "John Smith",
        avatar: "/placeholder.svg?height=40&width=40",
      },
      rating: 4,
      date: "2023-01-20",
      content:
        "Great work overall. The design was good, though I needed a couple of revisions to get it perfect. Would recommend this seller to others looking for logo design.",
      helpful: 17,
      notHelpful: 1,
      blockchain: {
        verified: true,
        transactionId: "0x8bd72a3c4b5d6e7f8a9b0c1d2e3f4a5b6c7d8e9f",
      },
    },
    {
      id: 3,
      user: {
        name: "Sophia Chen",
        avatar: "/placeholder.svg?height=40&width=40",
      },
      rating: 5,
      date: "2022-12-05",
      content:
        "Exceptional service and quality! The logo design exceeded my expectations. It perfectly captures our brand's essence. The designer was responsive, professional, and delivered ahead of schedule.",
      helpful: 32,
      notHelpful: 0,
      blockchain: {
        verified: true,
        transactionId: "0x9ce83b5d6f7g8h9i0j1k2l3m4n5o6p7q8r9s0t",
      },
    },
  ]

  return (
    <div className="space-y-6">
      <div className="flex flex-col gap-6 md:flex-row md:items-center md:justify-between">
        <div>
          <h3 className="text-xl font-bold">Customer Reviews</h3>
          <div className="mt-2 flex items-center gap-2">
            <div className="flex">
              {[1, 2, 3, 4, 5].map((star) => (
                <Star
                  key={star}
                  className={`h-5 w-5 ${
                    star <= Math.round(rating) ? "fill-yellow-400 text-yellow-400" : "text-muted-foreground"
                  }`}
                />
              ))}
            </div>
            <span className="font-medium">{rating} out of 5</span>
            <span className="text-muted-foreground">({reviewCount} reviews)</span>
          </div>
        </div>
        <Button variant="outline">Write a Review</Button>
      </div>

      <div className="space-y-6">
        {reviews.map((review) => (
          <Card key={review.id}>
            <CardContent className="p-6">
              <div className="flex items-start justify-between">
                <div className="flex items-start gap-4">
                  <Image
                    src={review.user.avatar || "/placeholder.svg"}
                    alt={review.user.name}
                    width={40}
                    height={40}
                    className="rounded-full"
                  />
                  <div>
                    <div className="flex items-center gap-2">
                      <h4 className="font-medium">{review.user.name}</h4>
                      <div className="flex items-center gap-1 text-yellow-400">
                        <div className="flex">
                          {[1, 2, 3, 4, 5].map((star) => (
                            <Star key={star} className={`h-4 w-4 ${star <= review.rating ? "fill-yellow-400" : ""}`} />
                          ))}
                        </div>
                      </div>
                    </div>
                    <p className="text-sm text-muted-foreground">
                      {new Date(review.date).toLocaleDateString("en-US", {
                        year: "numeric",
                        month: "long",
                        day: "numeric",
                      })}
                    </p>
                  </div>
                </div>
                {review.blockchain.verified && (
                  <div className="flex items-center gap-1 text-emerald-500">
                    <Shield className="h-4 w-4" />
                    <span className="text-xs font-medium">Blockchain Verified</span>
                  </div>
                )}
              </div>

              <div className="mt-4">
                <p className="text-sm">{review.content}</p>
              </div>

              <div className="mt-4 flex items-center justify-between">
                <div className="flex items-center gap-4">
                  <Button variant="ghost" size="sm" className="h-8 gap-1">
                    <ThumbsUp className="h-4 w-4" />
                    Helpful ({review.helpful})
                  </Button>
                  <Button variant="ghost" size="sm" className="h-8 gap-1">
                    <ThumbsDown className="h-4 w-4" />
                    Not Helpful ({review.notHelpful})
                  </Button>
                </div>
                {review.blockchain.verified && (
                  <Button variant="outline" size="sm" className="h-8 gap-1">
                    <ExternalLink className="h-3 w-3" />
                    <span className="text-xs">Verify on Chain</span>
                  </Button>
                )}
              </div>

              {review.blockchain.verified && (
                <div className="mt-3 rounded-md bg-muted/50 p-2 text-xs">
                  <div className="flex items-center justify-between">
                    <span className="font-mono text-muted-foreground">
                      Transaction: {review.blockchain.transactionId.substring(0, 18)}...
                    </span>
                  </div>
                </div>
              )}
            </CardContent>
          </Card>
        ))}
      </div>
    </div>
  )
}

