import Link from "next/link"
import { Button } from "@/components/ui/button"
import { ArrowRight, LayoutGrid, Search, ShieldCheck } from "lucide-react"

export default function HeroSection() {
  return (
    <section className="w-full py-12 md:py-24 lg:py-32 bg-gradient-to-b from-muted/50 to-background">
      <div className="container px-4 md:px-6">
        <div className="grid gap-6 lg:grid-cols-[1fr_400px] lg:gap-12 xl:grid-cols-[1fr_600px]">
          <div className="flex flex-col justify-center space-y-4">
            <div className="space-y-2">
              <h1 className="text-3xl font-bold tracking-tighter sm:text-5xl xl:text-6xl/none">
                Buy and Sell with Confidence
              </h1>
              <p className="max-w-[600px] text-muted-foreground md:text-xl">
                Our blockchain-verified marketplace connects freelancers and digital creators with buyers in a secure,
                transparent environment.
              </p>
            </div>
            <div className="flex flex-col gap-2 min-[400px]:flex-row">
              <Button asChild className="gap-1" size="lg">
                <Link href="/marketplace">
                  <LayoutGrid className="h-4 w-4" />
                  Explore Marketplace
                </Link>
              </Button>
              <Button asChild variant="outline" size="lg">
                <Link href="/how-it-works">
                  Learn More
                  <ArrowRight className="ml-2 h-4 w-4" />
                </Link>
              </Button>
            </div>
          </div>
          <div className="flex items-center justify-center">
            <div className="relative w-full">
              <div className="absolute -left-4 -top-4 h-72 w-72 rounded-full bg-primary/30 blur-3xl"></div>
              <div className="absolute -bottom-10 -right-10 h-72 w-72 rounded-full bg-secondary/30 blur-3xl"></div>
              <div className="relative rounded-xl border bg-background p-6 shadow-lg">
                <div className="space-y-4">
                  <div className="flex justify-between">
                    <div className="flex items-center gap-2">
                      <Search className="h-4 w-4 text-muted-foreground" />
                      <span className="text-sm font-medium">Popular Categories</span>
                    </div>
                    <Button variant="ghost" size="sm" className="text-xs">
                      View All
                    </Button>
                  </div>
                  <div className="grid grid-cols-2 gap-3">
                    {categories.map((category) => (
                      <Link
                        href={`/category/${category.slug}`}
                        key={category.title}
                        className="flex flex-col items-center gap-1 rounded-lg border bg-card p-3 text-center shadow-sm transition-colors hover:bg-accent hover:text-accent-foreground"
                      >
                        <category.icon className="h-10 w-10 opacity-75" />
                        <span className="text-xs font-medium">{category.title}</span>
                      </Link>
                    ))}
                  </div>

                  <div className="flex flex-col gap-4 rounded-lg border bg-muted/50 p-4">
                    <div className="flex items-center gap-2">
                      <ShieldCheck className="h-5 w-5 text-emerald-500" />
                      <span className="text-sm font-medium">Blockchain Verified</span>
                    </div>
                    <p className="text-xs text-muted-foreground">
                      All reviews and transactions are verified on blockchain for enhanced security and trust.
                    </p>
                    <Button asChild variant="outline" size="sm" className="w-full">
                      <Link href="/blockchain">Learn how it works</Link>
                    </Button>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>
  )
}

const categories = [
  {
    title: "Design",
    slug: "design",
    icon: function DesignIcon(props) {
      return (
        <svg
          {...props}
          xmlns="http://www.w3.org/2000/svg"
          width="24"
          height="24"
          viewBox="0 0 24 24"
          fill="none"
          stroke="currentColor"
          strokeWidth="2"
          strokeLinecap="round"
          strokeLinejoin="round"
        >
          <path d="M12 3a9 9 0 0 0 0 18c.83 0 1.5-.67 1.5-1.5 0-.39-.15-.74-.39-1.01-.23-.26-.38-.61-.38-1 0-.83.67-1.5 1.5-1.5H16c2.21 0 4-1.79 4-4 0-3.86-3.59-7-8-7Zm-5.5 9a1.5 1.5 0 1 1-.001-2.999A1.5 1.5 0 0 1 6.5 12Zm3-4a1.5 1.5 0 1 1-.001-2.999A1.5 1.5 0 0 1 9.5 8Zm3 0a1.5 1.5 0 1 1-.001-2.999A1.5 1.5 0 0 1 12.5 8Zm3 4a1.5 1.5 0 1 1-.001-2.999A1.5 1.5 0 0 1 15.5 12Z" />
        </svg>
      )
    },
  },
  {
    title: "Development",
    slug: "development",
    icon: function CodeIcon(props) {
      return (
        <svg
          {...props}
          xmlns="http://www.w3.org/2000/svg"
          width="24"
          height="24"
          viewBox="0 0 24 24"
          fill="none"
          stroke="currentColor"
          strokeWidth="2"
          strokeLinecap="round"
          strokeLinejoin="round"
        >
          <polyline points="16 18 22 12 16 6" />
          <polyline points="8 6 2 12 8 18" />
        </svg>
      )
    },
  },
  {
    title: "Marketing",
    slug: "marketing",
    icon: function TrendingUpIcon(props) {
      return (
        <svg
          {...props}
          xmlns="http://www.w3.org/2000/svg"
          width="24"
          height="24"
          viewBox="0 0 24 24"
          fill="none"
          stroke="currentColor"
          strokeWidth="2"
          strokeLinecap="round"
          strokeLinejoin="round"
        >
          <polyline points="23 6 13.5 15.5 8.5 10.5 1 18" />
          <polyline points="17 6 23 6 23 12" />
        </svg>
      )
    },
  },
  {
    title: "Writing",
    slug: "writing",
    icon: function EditIcon(props) {
      return (
        <svg
          {...props}
          xmlns="http://www.w3.org/2000/svg"
          width="24"
          height="24"
          viewBox="0 0 24 24"
          fill="none"
          stroke="currentColor"
          strokeWidth="2"
          strokeLinecap="round"
          strokeLinejoin="round"
        >
          <path d="M12 20h9" />
          <path d="M16.5 3.5a2.121 2.121 0 0 1 3 3L7 19l-4 1 1-4L16.5 3.5z" />
        </svg>
      )
    },
  },
]

