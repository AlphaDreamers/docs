import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Card, CardHeader, CardTitle } from "@/components/ui/card"
import { Input } from "@/components/ui/input"
import { Button } from "@/components/ui/button"
import { Badge } from "@/components/ui/badge"
import { Search, Filter, Bell, Info } from "lucide-react"
import ChatList from "@/components/chat/chat-list"
import ChatInterface from "@/components/chat/chat-interface"

export default function MessagesPage() {
  return (
    <div className="container px-4 py-6 md:px-6 md:py-8">
      <div className="mb-6 flex flex-col justify-between gap-4 md:flex-row md:items-center">
        <div>
          <h1 className="text-3xl font-bold tracking-tight">Messages</h1>
          <p className="text-muted-foreground">Communicate with buyers and sellers about orders and listings</p>
        </div>
        <div className="flex items-center gap-2">
          <Button variant="outline" size="sm" className="h-8 gap-1">
            <Bell className="h-4 w-4" />
            <span className="hidden sm:inline">Notifications</span>
          </Button>
          <Button variant="outline" size="sm" className="h-8 gap-1">
            <Info className="h-4 w-4" />
            <span className="hidden sm:inline">Help</span>
          </Button>
        </div>
      </div>

      <div className="grid grid-cols-1 gap-6 md:grid-cols-12">
        <div className="md:col-span-4 lg:col-span-3">
          <Card className="h-[calc(100vh-12rem)] overflow-hidden">
            <CardHeader className="p-4">
              <div className="flex items-center justify-between">
                <CardTitle>Conversations</CardTitle>
                <Badge variant="outline" className="ml-2">
                  3 Unread
                </Badge>
              </div>
              <div className="flex gap-2">
                <div className="relative flex-1">
                  <Search className="absolute left-2 top-2.5 h-4 w-4 text-muted-foreground" />
                  <Input placeholder="Search messages..." className="pl-8" />
                </div>
                <Button variant="outline" size="icon" className="h-10 w-10">
                  <Filter className="h-4 w-4" />
                </Button>
              </div>
              <Tabs defaultValue="all" className="w-full">
                <TabsList className="grid w-full grid-cols-3">
                  <TabsTrigger value="all">All</TabsTrigger>
                  <TabsTrigger value="unread">Unread</TabsTrigger>
                  <TabsTrigger value="archived">Archived</TabsTrigger>
                </TabsList>
                <div className="h-[calc(100vh-20rem)] overflow-y-auto">
                  <TabsContent value="all" className="m-0">
                    <ChatList activeChat="chat1" />
                  </TabsContent>
                  <TabsContent value="unread" className="m-0">
                    <ChatList activeChat="chat1" filter="unread" />
                  </TabsContent>
                  <TabsContent value="archived" className="m-0">
                    <div className="flex h-40 items-center justify-center">
                      <p className="text-sm text-muted-foreground">No archived conversations</p>
                    </div>
                  </TabsContent>
                </div>
              </Tabs>
            </CardHeader>
          </Card>
        </div>

        <div className="md:col-span-8 lg:col-span-9">
          <Card className="h-[calc(100vh-12rem)] overflow-hidden">
            {/* This would be conditionally rendered based on selected chat */}
            <ChatInterface chatId="chat1" />
            {/* <EmptyChat /> */}
          </Card>
        </div>
      </div>
    </div>
  )
}

