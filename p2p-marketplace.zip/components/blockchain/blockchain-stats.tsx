import { Card, CardContent } from "@/components/ui/card"
import { ArrowUpRight, Database, FileCheck, Tag, Users } from "lucide-react"

export default function BlockchainStats() {
  return (
    <div className="grid gap-4 sm:grid-cols-2 lg:grid-cols-4">
      {stats.map((stat, index) => (
        <Card key={index}>
          <CardContent className="p-4">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm font-medium text-muted-foreground">{stat.name}</p>
                <p className="text-2xl font-bold">{stat.value}</p>
              </div>
              <div className={`rounded-full p-2 ${stat.bgColor}`}>
                <stat.icon className={`h-5 w-5 ${stat.iconColor}`} />
              </div>
            </div>
            <div className="mt-4 flex items-center text-xs">
              <div className={`flex items-center ${stat.trend > 0 ? "text-emerald-500" : "text-red-500"}`}>
                <ArrowUpRight className={`mr-1 h-3 w-3 ${stat.trend < 0 ? "rotate-90" : ""}`} />
                <span>
                  {Math.abs(stat.trend)}% {stat.trend > 0 ? "increase" : "decrease"}
                </span>
              </div>
              <span className="ml-1 text-muted-foreground">vs. last week</span>
            </div>
          </CardContent>
        </Card>
      ))}
    </div>
  )
}

const stats = [
  {
    name: "Total Transactions",
    value: "5,120",
    icon: Database,
    trend: 12.5,
    bgColor: "bg-blue-100 dark:bg-blue-900/20",
    iconColor: "text-blue-500",
  },
  {
    name: "Verified Reviews",
    value: "876",
    icon: FileCheck,
    trend: 8.2,
    bgColor: "bg-emerald-100 dark:bg-emerald-900/20",
    iconColor: "text-emerald-500",
  },
  {
    name: "Active Listings",
    value: "1,243",
    icon: Tag,
    trend: -3.1,
    bgColor: "bg-orange-100 dark:bg-orange-900/20",
    iconColor: "text-orange-500",
  },
  {
    name: "Verified Users",
    value: "3,587",
    icon: Users,
    trend: 5.7,
    bgColor: "bg-purple-100 dark:bg-purple-900/20",
    iconColor: "text-purple-500",
  },
]

