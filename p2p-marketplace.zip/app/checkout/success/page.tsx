import Link from "next/link"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card"
import { CheckCircle, MessageCircle } from "lucide-react"

export default function CheckoutSuccessPage({ searchParams }: { searchParams: { method?: string } }) {
  const isCryptoPayment = searchParams.method === "crypto"

  return (
    <div className="container flex items-center justify-center px-4 py-12 md:px-6 md:py-24">
      <Card className="mx-auto max-w-md">
        <CardHeader className="text-center">
          <div className="flex justify-center">
            <div className="rounded-full bg-emerald-100 p-3 dark:bg-emerald-900/20">
              <CheckCircle className="h-12 w-12 text-emerald-500" />
            </div>
          </div>
          <CardTitle className="text-2xl">Payment Successful!</CardTitle>
          <CardDescription>
            Your order has been placed and {isCryptoPayment ? "cryptocurrency" : "payment"} has been processed
            successfully.
          </CardDescription>
        </CardHeader>
        <CardContent className="space-y-4">
          <div className="rounded-lg border p-4">
            <div className="space-y-2">
              <div className="flex justify-between">
                <span className="text-sm text-muted-foreground">Order ID</span>
                <span className="text-sm font-medium">ORD-12345</span>
              </div>
              <div className="flex justify-between">
                <span className="text-sm text-muted-foreground">Date</span>
                <span className="text-sm font-medium">
                  {new Date().toLocaleDateString("en-US", {
                    month: "long",
                    day: "numeric",
                    year: "numeric",
                  })}
                </span>
              </div>
              <div className="flex justify-between">
                <span className="text-sm text-muted-foreground">Total Amount</span>
                <span className="text-sm font-medium">{isCryptoPayment ? "132.00 USDT" : "$132.00"}</span>
              </div>
              <div className="flex justify-between">
                <span className="text-sm text-muted-foreground">Payment Method</span>
                <span className="text-sm font-medium">
                  {isCryptoPayment ? "USDT (Tether)" : "Credit Card (•••• 4242)"}
                </span>
              </div>
            </div>
          </div>

          <div className="rounded-lg bg-muted p-4 text-center">
            <p className="text-sm">
              {isCryptoPayment
                ? "Your cryptocurrency payment has been verified. The transaction is recorded on the blockchain for transparency."
                : "Your payment is held in escrow until you confirm the work is completed to your satisfaction."}
            </p>
          </div>

          <div className="space-y-2">
            <p className="text-center text-sm text-muted-foreground">
              A confirmation email has been sent to your registered email address.
            </p>
            <p className="text-center text-sm text-muted-foreground">
              You can track your order status in your dashboard.
            </p>
          </div>
        </CardContent>
        <CardFooter className="flex flex-col space-y-2">
          <Button asChild className="w-full">
            <Link href="/orders/ORD-12345">View Order Details</Link>
          </Button>
          <Button variant="outline" asChild className="w-full">
            <Link href="/messages?chat=chat1">
              <MessageCircle className="mr-2 h-4 w-4" />
              Message Seller
            </Link>
          </Button>
          <Button variant="link" asChild className="w-full">
            <Link href="/marketplace">Continue Shopping</Link>
          </Button>
        </CardFooter>
      </Card>
    </div>
  )
}

