import { Button } from "@/components/ui/button"
import { MessageSquare } from "lucide-react"

export default function EmptyChat() {
  return (
    <div className="flex h-full flex-col items-center justify-center p-6">
      <div className="flex h-20 w-20 items-center justify-center rounded-full bg-primary/10">
        <MessageSquare className="h-10 w-10 text-primary" />
      </div>
      <h3 className="mt-6 text-xl font-medium">Your Messages</h3>
      <p className="mt-2 max-w-md text-center text-muted-foreground">
        Select a conversation from the list or start a new one to begin messaging with buyers and sellers.
      </p>
      <Button className="mt-6">Start New Conversation</Button>
    </div>
  )
}

