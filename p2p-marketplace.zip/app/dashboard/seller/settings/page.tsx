import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Bitcoin, CreditCard, DollarSign, Info } from "lucide-react"

export default function SellerSettingsPage() {
  return (
    <div className="container px-4 py-8 md:px-6 md:py:12">
      <div className="mb-8">
        <h1 className="text-3xl font-bold tracking-tight">Seller Settings</h1>
        <p className="text-muted-foreground">Manage your payment methods and account settings</p>
      </div>

      <Tabs defaultValue="payment" className="space-y-8">
        <TabsList>
          <TabsTrigger value="payment">Payment Methods</TabsTrigger>
          <TabsTrigger value="account">Account</TabsTrigger>
          <TabsTrigger value="notifications">Notifications</TabsTrigger>
        </TabsList>

        <TabsContent value="payment" className="space-y-6">
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <CreditCard className="h-5 w-5" />
                Stripe Connect
              </CardTitle>
              <CardDescription>
                Connect your Stripe account to receive payments directly to your bank account
              </CardDescription>
            </CardHeader>
            <CardContent>
              <div className="rounded-lg border p-4 bg-muted/50">
                <div className="flex items-start gap-3">
                  <div className="rounded-full bg-primary/10 p-2">
                    <DollarSign className="h-5 w-5 text-primary" />
                  </div>
                  <div>
                    <h3 className="font-medium">Stripe Connected</h3>
                    <p className="text-sm text-muted-foreground mt-1">
                      Your Stripe account is connected and ready to receive payments.
                    </p>
                    <div className="mt-3">
                      <Button variant="outline" size="sm">
                        Manage Stripe Account
                      </Button>
                    </div>
                  </div>
                </div>
              </div>
            </CardContent>
          </Card>

          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <Bitcoin className="h-5 w-5" />
                Cryptocurrency Wallets
              </CardTitle>
              <CardDescription>Add your cryptocurrency wallet addresses to receive payments in crypto</CardDescription>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="space-y-2">
                <Label htmlFor="usdt-address">USDT Address (ERC-20)</Label>
                <Input
                  id="usdt-address"
                  placeholder="0x..."
                  defaultValue="0x742d35Cc6634C0532925a3b844Bc454e4438f44e"
                  className="font-mono"
                />
                <p className="text-xs text-muted-foreground">
                  This address will be shown to buyers who choose to pay with USDT
                </p>
              </div>

              <div className="space-y-2">
                <Label htmlFor="btc-address">Bitcoin Address</Label>
                <Input id="btc-address" placeholder="bc1..." defaultValue="" className="font-mono" />
              </div>

              <div className="space-y-2">
                <Label htmlFor="eth-address">Ethereum Address</Label>
                <Input
                  id="eth-address"
                  placeholder="0x..."
                  defaultValue="0x742d35Cc6634C0532925a3b844Bc454e4438f44e"
                  className="font-mono"
                />
              </div>

              <div className="rounded-md bg-muted p-3">
                <div className="flex items-start gap-2">
                  <Info className="h-4 w-4 text-muted-foreground mt-0.5" />
                  <div className="text-xs text-muted-foreground">
                    <p>
                      Make sure to double-check your wallet addresses. Incorrect addresses may result in permanent loss
                      of funds.
                    </p>
                  </div>
                </div>
              </div>
            </CardContent>
            <CardFooter>
              <Button>Save Wallet Addresses</Button>
            </CardFooter>
          </Card>
        </TabsContent>

        <TabsContent value="account">
          <Card>
            <CardHeader>
              <CardTitle>Account Settings</CardTitle>
              <CardDescription>Manage your account details and preferences</CardDescription>
            </CardHeader>
            <CardContent>
              <p className="text-sm text-muted-foreground">Account settings content would go here</p>
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="notifications">
          <Card>
            <CardHeader>
              <CardTitle>Notification Preferences</CardTitle>
              <CardDescription>Manage how you receive notifications</CardDescription>
            </CardHeader>
            <CardContent>
              <p className="text-sm text-muted-foreground">Notification settings content would go here</p>
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>
    </div>
  )
}

