import Link from "next/link"
import Image from "next/image"
import { Button } from "@/components/ui/button"
import { Card, CardContent } from "@/components/ui/card"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Badge } from "@/components/ui/badge"
import {
  ArrowRight,
  CalendarDays,
  Check,
  Clock,
  ExternalLink,
  Heart,
  MessageCircle,
  Share2,
  Shield,
  ShoppingCart,
  Star,
  ThumbsUp,
} from "lucide-react"
import SellerInfo from "@/components/marketplace/seller-info"
import ReviewsList from "@/components/marketplace/reviews-list"

export default function ListingPage({ params }: { params: { id: string } }) {
  // For a real app, we would fetch the listing data from an API
  // For this prototype, we'll just use mock data
  const listing = {
    id: params.id,
    title: "Professional Logo Design",
    description: "I will create a modern, memorable logo for your brand with unlimited revisions",
    longDescription: `
      I specialize in creating unique, professional logos that help your brand stand out. With over 5 years of experience working with clients from startups to established businesses, I provide a comprehensive logo design service.
      
      What's included:
      - Initial consultation to understand your brand and vision
      - 3 initial concepts to choose from
      - Unlimited revisions on your chosen concept
      - Final delivery in all file formats (AI, EPS, PDF, PNG, JPG)
      - Full copyright ownership
      - Brand style guide
      
      My process ensures you get a logo that perfectly represents your brand and meets your specific requirements. I believe in providing exceptional value and building long-term relationships with my clients.
    `,
    price: 120,
    rating: 4.9,
    reviewCount: 142,
    images: [
      "/placeholder.svg?height=400&width=600",
      "/placeholder.svg?height=400&width=600",
      "/placeholder.svg?height=400&width=600",
    ],
    seller: {
      id: "seller1",
      name: "Alex Morgan",
      avatar: "/placeholder.svg?height=80&width=80",
      memberSince: "January 2021",
      responseTime: "Within 2 hours",
      completedOrders: 347,
      verifiedSeller: true,
      rating: 4.9,
      bio: "Graphic designer with 8+ years of experience specializing in brand identity and logo design.",
    },
    type: "service",
    category: "Design",
    subcategory: "Logo Design",
    deliveryTime: "3 days",
    revisions: "Unlimited",
    features: [
      "Original concepts",
      "Vector files included",
      "Logo transparency",
      "3D mockup",
      "Source files",
      "High resolution",
    ],
    blockchain: {
      verified: true,
      transactionId: "0x8fe72a3c4b5d6e7f8a9b0c1d2e3f4a5b6c7d8e9f",
      blockNumber: 14356789,
      timestamp: "2023-08-15T14:23:45Z",
    },
    faqs: [
      {
        question: "How many revisions do I get?",
        answer: "You get unlimited revisions until you're completely satisfied with the final design.",
      },
      {
        question: "What file formats will I receive?",
        answer: "You'll receive all industry-standard formats including AI, EPS, PDF, PNG, and JPG.",
      },
      {
        question: "Do I own the copyright to the logo?",
        answer: "Yes, once the project is complete and payment is made, you own full copyright to the logo.",
      },
    ],
  }

  return (
    <div className="container px-4 py-6 md:px-6 lg:py-8">
      <div className="grid gap-6 lg:grid-cols-3 lg:gap-12">
        <div className="lg:col-span-2">
          <div className="flex flex-col space-y-6">
            <div className="flex flex-col space-y-2">
              <div className="flex items-center space-x-2">
                <Badge variant="secondary">{listing.category}</Badge>
                <Badge variant="secondary">{listing.subcategory}</Badge>
                <Badge variant="outline" className="flex items-center gap-1">
                  <Shield className="h-3 w-3 text-emerald-500" />
                  <span className="text-xs text-emerald-500">Blockchain Verified</span>
                </Badge>
              </div>
              <h1 className="text-3xl font-bold">{listing.title}</h1>
              <div className="flex items-center space-x-1 text-sm">
                <div className="flex items-center">
                  <Star className="h-4 w-4 fill-yellow-400 text-yellow-400" />
                  <span className="ml-1 font-medium">{listing.rating}</span>
                </div>
                <span className="text-muted-foreground">({listing.reviewCount} reviews)</span>
                <span className="text-muted-foreground">•</span>
                <span className="text-muted-foreground">{listing.completedOrders} orders completed</span>
              </div>
            </div>

            <div className="relative aspect-video overflow-hidden rounded-lg">
              <Image src={listing.images[0] || "/placeholder.svg"} alt={listing.title} fill className="object-cover" />
            </div>

            <div className="grid grid-cols-3 gap-2">
              {listing.images.slice(1).map((image, index) => (
                <div key={index} className="relative aspect-video overflow-hidden rounded-lg">
                  <Image
                    src={image || "/placeholder.svg"}
                    alt={`${listing.title} ${index + 2}`}
                    fill
                    className="object-cover"
                  />
                </div>
              ))}
            </div>

            <Tabs defaultValue="description" className="w-full">
              <TabsList className="w-full justify-start bg-background border-b rounded-none h-auto p-0">
                <TabsTrigger
                  value="description"
                  className="rounded-none data-[state=active]:border-b-2 data-[state=active]:border-primary h-10"
                >
                  Description
                </TabsTrigger>
                <TabsTrigger
                  value="reviews"
                  className="rounded-none data-[state=active]:border-b-2 data-[state=active]:border-primary h-10"
                >
                  Reviews ({listing.reviewCount})
                </TabsTrigger>
                <TabsTrigger
                  value="faqs"
                  className="rounded-none data-[state=active]:border-b-2 data-[state=active]:border-primary h-10"
                >
                  FAQs
                </TabsTrigger>
              </TabsList>
              <TabsContent value="description" className="mt-6">
                <div className="space-y-6">
                  <div className="space-y-4">
                    <h3 className="text-xl font-bold">About This Service</h3>
                    <div className="space-y-4">
                      {listing.longDescription.split("\n\n").map((paragraph, i) => (
                        <p key={i} className="leading-relaxed text-muted-foreground">
                          {paragraph}
                        </p>
                      ))}
                    </div>
                  </div>

                  {listing.type === "service" && (
                    <div className="space-y-4">
                      <h3 className="text-xl font-bold">Service Features</h3>
                      <ul className="grid grid-cols-1 gap-2 sm:grid-cols-2">
                        {listing.features.map((feature, i) => (
                          <li key={i} className="flex items-center gap-2">
                            <Check className="h-5 w-5 text-emerald-500" />
                            <span>{feature}</span>
                          </li>
                        ))}
                      </ul>
                    </div>
                  )}

                  <div className="space-y-4">
                    <h3 className="text-xl font-bold">Blockchain Verification</h3>
                    <Card>
                      <CardContent className="p-4">
                        <div className="flex items-center justify-between">
                          <div>
                            <p className="text-sm font-medium">Transaction ID</p>
                            <p className="text-xs text-muted-foreground font-mono">
                              {listing.blockchain.transactionId}
                            </p>
                          </div>
                          <Button variant="outline" size="sm" className="gap-1">
                            <ExternalLink className="h-4 w-4" />
                            View on Chain
                          </Button>
                        </div>
                        <div className="mt-4 flex items-center gap-4">
                          <div>
                            <p className="text-xs text-muted-foreground">Block</p>
                            <p className="text-sm">{listing.blockchain.blockNumber}</p>
                          </div>
                          <div>
                            <p className="text-xs text-muted-foreground">Timestamp</p>
                            <p className="text-sm">{new Date(listing.blockchain.timestamp).toLocaleDateString()}</p>
                          </div>
                          <div className="ml-auto flex items-center gap-1 text-emerald-500">
                            <Shield className="h-4 w-4" />
                            <span className="text-sm font-medium">Verified on Blockchain</span>
                          </div>
                        </div>
                      </CardContent>
                    </Card>
                  </div>
                </div>
              </TabsContent>

              <TabsContent value="reviews" className="mt-6">
                <ReviewsList listingId={listing.id} reviewCount={listing.reviewCount} rating={listing.rating} />
              </TabsContent>

              <TabsContent value="faqs" className="mt-6">
                <div className="space-y-6">
                  <h3 className="text-xl font-bold">Frequently Asked Questions</h3>
                  <div className="space-y-4">
                    {listing.faqs.map((faq, i) => (
                      <div key={i} className="space-y-2">
                        <h4 className="font-medium">{faq.question}</h4>
                        <p className="text-muted-foreground">{faq.answer}</p>
                      </div>
                    ))}
                  </div>
                </div>
              </TabsContent>
            </Tabs>
          </div>
        </div>

        <div className="lg:col-span-1">
          <div className="sticky top-6 space-y-6">
            <Card>
              <CardContent className="p-6">
                <div className="space-y-6">
                  <div>
                    <h3 className="text-xl font-bold">${listing.price}</h3>
                    {listing.type === "service" && (
                      <div className="mt-1 flex items-center gap-1 text-sm text-muted-foreground">
                        <Clock className="h-4 w-4" />
                        <span>Delivery in {listing.deliveryTime}</span>
                      </div>
                    )}
                  </div>

                  <div className="flex flex-col gap-3">
                    <Button className="w-full gap-2" asChild>
                      <Link href={`/checkout/${listing.id}`}>
                        <ShoppingCart className="h-4 w-4" />
                        {listing.type === "service" ? "Order Now" : "Buy Now"}
                      </Link>
                    </Button>
                    <Button variant="outline" className="w-full gap-2" asChild>
                      <Link href={`/messages?seller=${listing.seller.id}&listing=${listing.id}`}>
                        <MessageCircle className="h-4 w-4" /> Contact Seller
                      </Link>
                    </Button>
                    <div className="flex gap-2">
                      <Button variant="ghost" size="icon" className="rounded-full">
                        <Heart className="h-4 w-4" />
                      </Button>
                      <Button variant="ghost" size="icon" className="rounded-full">
                        <Share2 className="h-4 w-4" />
                      </Button>
                    </div>
                  </div>

                  {listing.type === "service" && (
                    <div className="space-y-3">
                      <div className="flex justify-between text-sm">
                        <span className="flex items-center gap-1">
                          <CalendarDays className="h-4 w-4" /> Delivery Time
                        </span>
                        <span className="font-medium">{listing.deliveryTime}</span>
                      </div>
                      <div className="flex justify-between text-sm">
                        <span className="flex items-center gap-1">
                          <ThumbsUp className="h-4 w-4" /> Revisions
                        </span>
                        <span className="font-medium">{listing.revisions}</span>
                      </div>
                    </div>
                  )}
                </div>
              </CardContent>
            </Card>

            <SellerInfo seller={listing.seller} />

            <div className="text-center">
              <Button variant="link" asChild>
                <Link href="/report" className="text-sm text-muted-foreground">
                  Report this listing
                </Link>
              </Button>
            </div>
          </div>
        </div>
      </div>

      <div className="mt-12">
        <div className="flex items-center justify-between">
          <h2 className="text-2xl font-bold">Similar Listings</h2>
          <Button variant="link" asChild>
            <Link href="/marketplace" className="flex items-center">
              View all <ArrowRight className="ml-1 h-4 w-4" />
            </Link>
          </Button>
        </div>
        <div className="mt-6 grid grid-cols-1 gap-6 sm:grid-cols-2 lg:grid-cols-4">
          {similarListings.map((listing) => (
            <Link href={`/marketplace/${listing.id}`} key={listing.id} className="group">
              <div className="overflow-hidden rounded-lg border">
                <div className="relative aspect-video overflow-hidden">
                  <Image
                    src={listing.image || "/placeholder.svg"}
                    alt={listing.title}
                    fill
                    className="object-cover transition-transform group-hover:scale-105"
                  />
                </div>
                <div className="p-4">
                  <h3 className="font-medium line-clamp-1 group-hover:text-primary">{listing.title}</h3>
                  <div className="mt-1 flex items-center text-sm">
                    <div className="flex items-center">
                      <Star className="h-3 w-3 fill-yellow-400 text-yellow-400" />
                      <span className="ml-1 font-medium">{listing.rating}</span>
                    </div>
                    <span className="ml-1 text-muted-foreground">({listing.reviewCount})</span>
                  </div>
                  <p className="mt-2 font-medium">${listing.price}</p>
                </div>
              </div>
            </Link>
          ))}
        </div>
      </div>
    </div>
  )
}

const similarListings = [
  {
    id: "2",
    title: "Business Card Design",
    description: "Professional business card designs with modern templates",
    price: 75,
    rating: 4.8,
    reviewCount: 98,
    image: "/placeholder.svg?height=200&width=300",
  },
  {
    id: "3",
    title: "Brand Identity Package",
    description: "Complete brand identity including logo, colors, and style guide",
    price: 350,
    rating: 4.9,
    reviewCount: 64,
    image: "/placeholder.svg?height=200&width=300",
  },
  {
    id: "4",
    title: "Social Media Kit",
    description: "Complete social media graphics package for all platforms",
    price: 120,
    rating: 4.7,
    reviewCount: 112,
    image: "/placeholder.svg?height=200&width=300",
  },
  {
    id: "5",
    title: "Custom Illustration",
    description: "Hand-drawn digital illustrations for your brand",
    price: 200,
    rating: 4.8,
    reviewCount: 52,
    image: "/placeholder.svg?height=200&width=300",
  },
]

