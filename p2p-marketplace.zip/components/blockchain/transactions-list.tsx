import Link from "next/link"
import { Badge } from "@/components/ui/badge"
import { CheckCircle2, Clock, FileText, Shield, Tag, ArrowLeftRight } from "lucide-react"

export default function TransactionsList() {
  return (
    <div className="space-y-4">
      {transactions.map((transaction) => (
        <Link
          key={transaction.hash}
          href={`/blockchain/scanner/tx/${transaction.hash}`}
          className="flex flex-col gap-2 rounded-lg border p-3 transition-colors hover:bg-muted/50 sm:flex-row sm:items-center sm:justify-between"
        >
          <div className="flex items-start gap-3">
            <div className={`mt-0.5 rounded-full p-1.5 ${transaction.iconBg}`}>
              <transaction.icon className={`h-4 w-4 ${transaction.iconColor}`} />
            </div>
            <div>
              <div className="flex items-center gap-2">
                <h4 className="font-medium">{transaction.type}</h4>
                <Badge variant={transaction.status === "Confirmed" ? "default" : "outline"}>{transaction.status}</Badge>
              </div>
              <p className="mt-1 text-xs font-mono text-muted-foreground">{transaction.hash.substring(0, 18)}...</p>
            </div>
          </div>
          <div className="flex flex-col items-end gap-1">
            <div className="flex items-center gap-1">
              <Clock className="h-3 w-3 text-muted-foreground" />
              <span className="text-xs text-muted-foreground">{transaction.time}</span>
            </div>
            {transaction.verified && (
              <div className="flex items-center gap-1 text-emerald-500">
                <Shield className="h-3 w-3" />
                <span className="text-xs">Blockchain Verified</span>
              </div>
            )}
          </div>
        </Link>
      ))}
    </div>
  )
}

const transactions = [
  {
    hash: "0x7ae92b4c6e8d9f0a1b2c3d4e5f6a7b8c9d0e1f2a",
    type: "Order Completion",
    status: "Confirmed",
    time: "15 min ago",
    verified: true,
    icon: CheckCircle2,
    iconBg: "bg-emerald-100 dark:bg-emerald-900/20",
    iconColor: "text-emerald-500",
  },
  {
    hash: "0x8bd72a3c4b5d6e7f8a9b0c1d2e3f4a5b6c7d8e9f",
    type: "Review Submission",
    status: "Confirmed",
    time: "2 hours ago",
    verified: true,
    icon: FileText,
    iconBg: "bg-blue-100 dark:bg-blue-900/20",
    iconColor: "text-blue-500",
  },
  {
    hash: "0x9ce83b5d6f7g8h9i0j1k2l3m4n5o6p7q8r9s0t",
    type: "Payment Processing",
    status: "Pending",
    time: "3 hours ago",
    verified: false,
    icon: ArrowLeftRight,
    iconBg: "bg-purple-100 dark:bg-purple-900/20",
    iconColor: "text-purple-500",
  },
  {
    hash: "0x1d2e3f4g5h6i7j8k9l0m1n2o3p4q5r6s7t8u9v",
    type: "Listing Creation",
    status: "Confirmed",
    time: "5 hours ago",
    verified: true,
    icon: Tag,
    iconBg: "bg-orange-100 dark:bg-orange-900/20",
    iconColor: "text-orange-500",
  },
]

