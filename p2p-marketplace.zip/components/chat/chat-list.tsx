"use client"

import { useState } from "react"
import Link from "next/link"
import Image from "next/image"
import { Badge } from "@/components/ui/badge"
import { cn } from "@/lib/utils"
import { CheckCircle, Clock, Package, ShoppingCart } from "lucide-react"

interface ChatListProps {
  activeChat?: string
  filter?: "all" | "unread" | "archived"
}

export default function ChatList({ activeChat, filter = "all" }: ChatListProps) {
  // In a real app, this would come from a database or API
  const [chats, setChats] = useState(mockChats)

  const filteredChats = filter === "unread" ? chats.filter((chat) => chat.unreadCount > 0) : chats

  return (
    <div className="flex flex-col">
      {filteredChats.length > 0 ? (
        filteredChats.map((chat) => (
          <Link
            key={chat.id}
            href={`/messages?chat=${chat.id}`}
            className={cn(
              "flex gap-3 border-b p-4 transition-colors hover:bg-muted/50",
              activeChat === chat.id && "bg-muted",
            )}
          >
            <div className="relative">
              <Image
                src={chat.avatar || "/placeholder.svg"}
                alt={chat.name}
                width={40}
                height={40}
                className="rounded-full"
              />
              {chat.online && (
                <span className="absolute bottom-0 right-0 h-3 w-3 rounded-full border-2 border-background bg-emerald-500"></span>
              )}
            </div>

            <div className="flex-1 min-w-0">
              <div className="flex items-center justify-between">
                <h4 className="font-medium truncate">{chat.name}</h4>
                <span className="text-xs text-muted-foreground">{chat.lastMessageTime}</span>
              </div>

              <div className="flex items-center gap-1 mt-1">
                {chat.context.type === "order" && <Package className="h-3 w-3 text-muted-foreground" />}
                {chat.context.type === "listing" && <ShoppingCart className="h-3 w-3 text-muted-foreground" />}
                <span className="text-xs text-muted-foreground truncate">{chat.context.title}</span>
              </div>

              <div className="flex items-center justify-between mt-1">
                <p className="text-sm text-muted-foreground truncate">{chat.lastMessage}</p>

                <div className="flex items-center gap-1">
                  {chat.status === "delivered" && <CheckCircle className="h-3 w-3 text-emerald-500" />}
                  {chat.status === "sent" && <CheckCircle className="h-3 w-3 text-muted-foreground" />}
                  {chat.status === "pending" && <Clock className="h-3 w-3 text-muted-foreground" />}

                  {chat.unreadCount > 0 && (
                    <Badge className="h-5 w-5 rounded-full p-0 flex items-center justify-center">
                      {chat.unreadCount}
                    </Badge>
                  )}
                </div>
              </div>
            </div>
          </Link>
        ))
      ) : (
        <div className="flex h-40 items-center justify-center">
          <p className="text-sm text-muted-foreground">No conversations found</p>
        </div>
      )}
    </div>
  )
}

// Mock data for the chat list
const mockChats = [
  {
    id: "chat1",
    name: "Emma Watson",
    avatar: "/placeholder.svg?height=40&width=40",
    lastMessage: "Thank you for the quick delivery!",
    lastMessageTime: "10:42 AM",
    unreadCount: 2,
    online: true,
    status: "delivered",
    context: {
      type: "order",
      id: "ORD-12345",
      title: "Professional Logo Design",
    },
  },
  {
    id: "chat2",
    name: "John Smith",
    avatar: "/placeholder.svg?height=40&width=40",
    lastMessage: "Is this still available?",
    lastMessageTime: "Yesterday",
    unreadCount: 0,
    online: false,
    status: "sent",
    context: {
      type: "listing",
      id: "2",
      title: "Social Media Strategy Pack",
    },
  },
  {
    id: "chat3",
    name: "Sophia Chen",
    avatar: "/placeholder.svg?height=40&width=40",
    lastMessage: "I'm interested in your services. Can we discuss the details?",
    lastMessageTime: "Yesterday",
    unreadCount: 1,
    online: true,
    status: "delivered",
    context: {
      type: "listing",
      id: "1",
      title: "Professional Logo Design",
    },
  },
  {
    id: "chat4",
    name: "Marcus Johnson",
    avatar: "/placeholder.svg?height=40&width=40",
    lastMessage: "The revisions look great! I'll approve the order now.",
    lastMessageTime: "2 days ago",
    unreadCount: 0,
    online: false,
    status: "sent",
    context: {
      type: "order",
      id: "ORD-12346",
      title: "Website Development",
    },
  },
  {
    id: "chat5",
    name: "Priya Sharma",
    avatar: "/placeholder.svg?height=40&width=40",
    lastMessage: "I've sent you the brand guidelines. Let me know if you need anything else.",
    lastMessageTime: "3 days ago",
    unreadCount: 0,
    online: false,
    status: "sent",
    context: {
      type: "order",
      id: "ORD-12347",
      title: "Brand Identity Package",
    },
  },
]

