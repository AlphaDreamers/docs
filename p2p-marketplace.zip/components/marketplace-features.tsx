import {
  ArrowUpDown,
  Bot,
  CheckCircle,
  CreditCard,
  MessageCircle,
  Shield,
  ShoppingBag,
  Star,
  UserCheck,
} from "lucide-react"

export default function MarketplaceFeatures() {
  const features = [
    {
      icon: UserCheck,
      title: "User Registration & KYC",
      description: "Secure account creation with KYC verification to establish trust and security",
    },
    {
      icon: ShoppingBag,
      title: "Browse & Search",
      description: "Find services and digital assets with powerful filters and categories",
    },
    {
      icon: ArrowUpDown,
      title: "Buy & Sell",
      description: "Seamlessly transition between buyer and seller roles in our marketplace",
    },
    {
      icon: CreditCard,
      title: "Secure Payments",
      description: "Payments processed securely with escrow protection for all transactions",
    },
    {
      icon: CheckCircle,
      title: "Order Completion",
      description: "Structured delivery and acceptance process for all orders",
    },
    {
      icon: Star,
      title: "Reviews & Ratings",
      description: "Build credibility through verified blockchain-backed reviews",
    },
    {
      icon: MessageCircle,
      title: "Real-Time Chat",
      description: "Direct communication between buyers and sellers for seamless collaboration",
    },
    {
      icon: Shield,
      title: "Blockchain Verification",
      description: "Transaction history and reviews verified on blockchain for transparency",
    },
    {
      icon: Bot,
      title: "Fraud Prevention",
      description: "Blockchain ensures authenticity and prevents fake reviews or listings",
    },
  ]

  return (
    <div className="grid grid-cols-1 gap-6 pt-10 sm:grid-cols-2 md:grid-cols-3">
      {features.map((feature, index) => (
        <div
          key={index}
          className="flex flex-col items-center gap-2 rounded-lg border bg-background p-6 text-center shadow-sm"
        >
          <div className="rounded-full bg-primary/10 p-3">
            <feature.icon className="h-6 w-6 text-primary" />
          </div>
          <h3 className="text-lg font-medium">{feature.title}</h3>
          <p className="text-sm text-muted-foreground">{feature.description}</p>
        </div>
      ))}
    </div>
  )
}

