import Link from "next/link"
import { Button } from "@/components/ui/button"
import { ChevronRight, Shield, Star } from "lucide-react"
import MarketplaceFeatures from "@/components/marketplace-features"
import HeroSection from "@/components/hero-section"

export default function Home() {
  return (
    <div className="flex flex-col min-h-screen">
      <HeroSection />

      {/* Main Features */}
      <section className="py-12 md:py-24 bg-muted/50">
        <div className="container px-4 md:px-6">
          <div className="flex flex-col items-center justify-center space-y-4 text-center">
            <div className="space-y-2">
              <div className="inline-block rounded-lg bg-muted px-3 py-1 text-sm">How It Works</div>
              <h2 className="text-3xl font-bold tracking-tighter sm:text-5xl">The marketplace for everyone</h2>
              <p className="max-w-[900px] text-muted-foreground md:text-xl/relaxed lg:text-base/relaxed xl:text-xl/relaxed">
                Our peer-to-peer platform connects freelancers and digital creators with buyers in a secure,
                blockchain-verified marketplace
              </p>
            </div>
          </div>
          <MarketplaceFeatures />
        </div>
      </section>

      {/* Testimonials */}
      <section className="py-12 md:py-24">
        <div className="container px-4 md:px-6">
          <div className="flex flex-col items-center justify-center space-y-4 text-center">
            <div className="space-y-2">
              <h2 className="text-3xl font-bold tracking-tighter sm:text-5xl">Trusted by freelancers and buyers</h2>
              <p className="max-w-[900px] text-muted-foreground md:text-xl/relaxed lg:text-base/relaxed xl:text-xl/relaxed">
                Join thousands of users who trust our platform for secure transactions and authentic reviews
              </p>
            </div>
          </div>
          <div className="mx-auto grid max-w-5xl items-center gap-6 py-12 lg:grid-cols-3">
            {testimonials.map((testimonial, index) => (
              <div key={index} className="rounded-lg border bg-background p-6">
                <div className="flex items-center gap-4">
                  <Star className="h-5 w-5 text-yellow-500" />
                  <Star className="h-5 w-5 text-yellow-500" />
                  <Star className="h-5 w-5 text-yellow-500" />
                  <Star className="h-5 w-5 text-yellow-500" />
                  <Star className="h-5 w-5 text-yellow-500" />
                </div>
                <p className="mt-4 text-muted-foreground">"{testimonial.comment}"</p>
                <div className="mt-6 flex items-center gap-4">
                  <img
                    src={testimonial.avatar || "/placeholder.svg"}
                    alt={testimonial.name}
                    className="rounded-full h-10 w-10 object-cover"
                  />
                  <div>
                    <h3 className="font-medium">{testimonial.name}</h3>
                    <p className="text-sm text-muted-foreground">{testimonial.role}</p>
                  </div>
                  <div className="ml-auto flex items-center gap-2 text-xs">
                    <Shield className="h-3 w-3 text-emerald-500" />
                    <span className="text-xs text-emerald-500">Blockchain Verified</span>
                  </div>
                </div>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* CTA */}
      <section className="py-12 md:py-24 bg-primary text-primary-foreground">
        <div className="container px-4 md:px-6">
          <div className="flex flex-col items-center justify-center space-y-4 text-center">
            <div className="space-y-2">
              <h2 className="text-3xl font-bold tracking-tighter sm:text-5xl">Start your journey today</h2>
              <p className="max-w-[600px] text-primary-foreground/80 md:text-xl/relaxed">
                Join our trusted marketplace and start buying or selling with confidence
              </p>
            </div>
            <div className="flex flex-col sm:flex-row gap-4">
              <Button asChild size="lg" variant="secondary">
                <Link href="/marketplace">Browse Marketplace</Link>
              </Button>
              <Button asChild size="lg">
                <Link href="/auth/signup">
                  Sign Up Now <ChevronRight className="ml-1 h-4 w-4" />
                </Link>
              </Button>
            </div>
          </div>
        </div>
      </section>
    </div>
  )
}

const testimonials = [
  {
    name: "Sophia Chen",
    role: "UI Designer",
    avatar: "/placeholder.svg?height=40&width=40",
    comment:
      "I've been selling my design assets here for 6 months, and the blockchain verification for reviews gives my clients confidence in my work.",
  },
  {
    name: "Marcus Johnson",
    role: "Web Developer",
    avatar: "/placeholder.svg?height=40&width=40",
    comment: "As a freelancer, I love the secure payment system and the ability to communicate directly with clients.",
  },
  {
    name: "Priya Sharma",
    role: "Marketing Manager",
    avatar: "/placeholder.svg?height=40&width=40",
    comment:
      "I've hired multiple freelancers here. The KYC verification and blockchain-backed reviews help me find reliable professionals.",
  },
]

