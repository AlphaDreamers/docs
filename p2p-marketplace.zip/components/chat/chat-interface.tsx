"use client"

import type React from "react"

import { useState, useRef, useEffect } from "react"
import Image from "next/image"
import Link from "next/link"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Badge } from "@/components/ui/badge"
import { Separator } from "@/components/ui/separator"
import { Card, CardContent } from "@/components/ui/card"
import {
  MoreHorizontal,
  Send,
  Paperclip,
  ImageIcon,
  Smile,
  Package,
  ExternalLink,
  Clock,
  Calendar,
  DollarSign,
  Shield,
} from "lucide-react"
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuLabel,
  DropdownMenuSeparator,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu"
import { Tooltip, TooltipContent, TooltipProvider, TooltipTrigger } from "@/components/ui/tooltip"

interface ChatInterfaceProps {
  chatId: string
}

export default function ChatInterface({ chatId }: ChatInterfaceProps) {
  const [message, setMessage] = useState("")
  const [messages, setMessages] = useState(mockMessages)
  const messagesEndRef = useRef<HTMLDivElement>(null)

  // Auto-scroll to bottom when messages change
  useEffect(() => {
    messagesEndRef.current?.scrollIntoView({ behavior: "smooth" })
  }, [messages])

  const handleSendMessage = () => {
    if (message.trim() === "") return

    const newMessage = {
      id: `msg-${Date.now()}`,
      sender: "me",
      content: message,
      timestamp: new Date().toLocaleTimeString([], { hour: "2-digit", minute: "2-digit" }),
      status: "sent",
    }

    setMessages([...messages, newMessage])
    setMessage("")
  }

  const handleKeyDown = (e: React.KeyboardEvent) => {
    if (e.key === "Enter" && !e.shiftKey) {
      e.preventDefault()
      handleSendMessage()
    }
  }

  // Find the chat details from the chat ID
  const chat = mockChats.find((c) => c.id === chatId)
  if (!chat) return null

  return (
    <>
      <div className="flex items-center justify-between border-b p-4">
        <div className="flex items-center gap-3">
          <div className="relative">
            <Image
              src={chat.avatar || "/placeholder.svg"}
              alt={chat.name}
              width={40}
              height={40}
              className="rounded-full"
            />
            {chat.online && (
              <span className="absolute bottom-0 right-0 h-3 w-3 rounded-full border-2 border-background bg-emerald-500"></span>
            )}
          </div>

          <div>
            <h3 className="font-medium">{chat.name}</h3>
            <div className="flex items-center gap-1">
              {chat.online ? (
                <span className="text-xs text-emerald-500">Online</span>
              ) : (
                <span className="text-xs text-muted-foreground">Last seen today at 9:34 AM</span>
              )}
            </div>
          </div>
        </div>

        <div className="flex items-center gap-2">
          <TooltipProvider>
            <Tooltip>
              <TooltipTrigger asChild>
                <Button variant="ghost" size="icon" asChild>
                  <Link href={`/orders/${chat.context.id}`}>
                    <Package className="h-5 w-5" />
                  </Link>
                </Button>
              </TooltipTrigger>
              <TooltipContent>
                <p>View Order Details</p>
              </TooltipContent>
            </Tooltip>
          </TooltipProvider>

          <DropdownMenu>
            <DropdownMenuTrigger asChild>
              <Button variant="ghost" size="icon">
                <MoreHorizontal className="h-5 w-5" />
              </Button>
            </DropdownMenuTrigger>
            <DropdownMenuContent align="end">
              <DropdownMenuLabel>Options</DropdownMenuLabel>
              <DropdownMenuItem>View Profile</DropdownMenuItem>
              <DropdownMenuItem>Search in Conversation</DropdownMenuItem>
              <DropdownMenuSeparator />
              <DropdownMenuItem>Mute Notifications</DropdownMenuItem>
              <DropdownMenuItem>Block User</DropdownMenuItem>
              <DropdownMenuItem className="text-destructive">Report Issue</DropdownMenuItem>
            </DropdownMenuContent>
          </DropdownMenu>
        </div>
      </div>

      <div className="flex h-[calc(100%-10rem)] flex-col">
        <div className="flex-1 overflow-y-auto p-4">
          {/* Order context card */}
          <div className="mb-6 flex justify-center">
            <Card className="w-full max-w-md">
              <CardContent className="p-4">
                <div className="flex items-start gap-3">
                  <div className="rounded-md bg-primary/10 p-2">
                    <Package className="h-6 w-6 text-primary" />
                  </div>
                  <div className="flex-1">
                    <div className="flex items-center justify-between">
                      <h4 className="font-medium">{chat.context.title}</h4>
                      <Badge variant="outline">Active</Badge>
                    </div>
                    <p className="mt-1 text-sm text-muted-foreground">Order #{chat.context.id}</p>

                    <div className="mt-3 grid grid-cols-2 gap-2 text-sm">
                      <div className="flex items-center gap-1">
                        <Clock className="h-3 w-3 text-muted-foreground" />
                        <span>Delivery: 3 days</span>
                      </div>
                      <div className="flex items-center gap-1">
                        <Calendar className="h-3 w-3 text-muted-foreground" />
                        <span>Due: Aug 18, 2023</span>
                      </div>
                      <div className="flex items-center gap-1">
                        <DollarSign className="h-3 w-3 text-muted-foreground" />
                        <span>Amount: $120</span>
                      </div>
                      <div className="flex items-center gap-1">
                        <Shield className="h-3 w-3 text-emerald-500" />
                        <span className="text-emerald-500">Blockchain Verified</span>
                      </div>
                    </div>

                    <div className="mt-3">
                      <Button variant="outline" size="sm" className="w-full gap-1" asChild>
                        <Link href={`/orders/${chat.context.id}`}>
                          View Order Details
                          <ExternalLink className="ml-1 h-3 w-3" />
                        </Link>
                      </Button>
                    </div>
                  </div>
                </div>
              </CardContent>
            </Card>
          </div>

          {/* Date separator */}
          <div className="relative my-6">
            <Separator />
            <div className="absolute left-1/2 top-1/2 -translate-x-1/2 -translate-y-1/2 bg-background px-2 text-xs text-muted-foreground">
              Today
            </div>
          </div>

          {/* Messages */}
          <div className="space-y-4">
            {messages.map((msg) => (
              <div key={msg.id} className={`flex ${msg.sender === "me" ? "justify-end" : "justify-start"}`}>
                {msg.sender !== "me" && (
                  <div className="mr-2 mt-1">
                    <Image
                      src={chat.avatar || "/placeholder.svg"}
                      alt={chat.name}
                      width={32}
                      height={32}
                      className="rounded-full"
                    />
                  </div>
                )}

                <div className={`max-w-[70%] ${msg.sender === "me" ? "order-1" : "order-2"}`}>
                  <div
                    className={`rounded-lg p-3 ${
                      msg.sender === "me" ? "bg-primary text-primary-foreground" : "bg-muted"
                    }`}
                  >
                    <p className="text-sm">{msg.content}</p>
                  </div>

                  <div
                    className={`mt-1 flex items-center gap-1 text-xs text-muted-foreground ${
                      msg.sender === "me" ? "justify-end" : "justify-start"
                    }`}
                  >
                    <span>{msg.timestamp}</span>
                    {msg.sender === "me" && msg.status === "read" && <span className="text-primary">✓✓</span>}
                    {msg.sender === "me" && msg.status === "delivered" && <span>✓✓</span>}
                    {msg.sender === "me" && msg.status === "sent" && <span>✓</span>}
                  </div>
                </div>
              </div>
            ))}
            <div ref={messagesEndRef} />
          </div>
        </div>

        <div className="border-t p-4">
          <div className="flex items-end gap-2">
            <div className="flex gap-1">
              <TooltipProvider>
                <Tooltip>
                  <TooltipTrigger asChild>
                    <Button variant="ghost" size="icon" className="h-9 w-9">
                      <Paperclip className="h-5 w-5" />
                    </Button>
                  </TooltipTrigger>
                  <TooltipContent>
                    <p>Attach File</p>
                  </TooltipContent>
                </Tooltip>
              </TooltipProvider>

              <TooltipProvider>
                <Tooltip>
                  <TooltipTrigger asChild>
                    <Button variant="ghost" size="icon" className="h-9 w-9">
                      <ImageIcon className="h-5 w-5" />
                    </Button>
                  </TooltipTrigger>
                  <TooltipContent>
                    <p>Attach Image</p>
                  </TooltipContent>
                </Tooltip>
              </TooltipProvider>

              <TooltipProvider>
                <Tooltip>
                  <TooltipTrigger asChild>
                    <Button variant="ghost" size="icon" className="h-9 w-9">
                      <Smile className="h-5 w-5" />
                    </Button>
                  </TooltipTrigger>
                  <TooltipContent>
                    <p>Add Emoji</p>
                  </TooltipContent>
                </Tooltip>
              </TooltipProvider>
            </div>

            <div className="relative flex-1">
              <Input
                placeholder="Type a message..."
                value={message}
                onChange={(e) => setMessage(e.target.value)}
                onKeyDown={handleKeyDown}
                className="pr-10"
              />
            </div>

            <Button onClick={handleSendMessage} disabled={message.trim() === ""} size="icon" className="h-9 w-9">
              <Send className="h-4 w-4" />
            </Button>
          </div>
        </div>
      </div>
    </>
  )
}

// Mock data for the chat interface
const mockChats = [
  {
    id: "chat1",
    name: "Emma Watson",
    avatar: "/placeholder.svg?height=40&width=40",
    online: true,
    context: {
      type: "order",
      id: "ORD-12345",
      title: "Professional Logo Design",
    },
  },
]

const mockMessages = [
  {
    id: "msg1",
    sender: "other",
    content: "Hi there! I'm excited about the logo design project. Could you tell me more about your requirements?",
    timestamp: "9:30 AM",
    status: "read",
  },
  {
    id: "msg2",
    sender: "me",
    content: "Hello! Thanks for accepting my order. I'm looking for a minimalist logo for my tech startup.",
    timestamp: "9:32 AM",
    status: "read",
  },
  {
    id: "msg3",
    sender: "other",
    content: "That sounds great! Do you have any specific color preferences or examples of logos you like?",
    timestamp: "9:35 AM",
    status: "read",
  },
  {
    id: "msg4",
    sender: "me",
    content: "I prefer blue and gray tones. I'll send you some examples of logos I like for inspiration.",
    timestamp: "9:40 AM",
    status: "read",
  },
  {
    id: "msg5",
    sender: "other",
    content:
      "Perfect! I'll start working on some concepts based on your preferences. I should have initial drafts ready by tomorrow.",
    timestamp: "9:45 AM",
    status: "read",
  },
  {
    id: "msg6",
    sender: "me",
    content: "That sounds great! Looking forward to seeing the drafts.",
    timestamp: "9:47 AM",
    status: "read",
  },
  {
    id: "msg7",
    sender: "other",
    content:
      "I've completed the initial drafts earlier than expected! I'm attaching three concept options for you to review.",
    timestamp: "10:30 AM",
    status: "read",
  },
  {
    id: "msg8",
    sender: "other",
    content: "Let me know which direction you prefer, and we can refine from there.",
    timestamp: "10:31 AM",
    status: "read",
  },
  {
    id: "msg9",
    sender: "me",
    content:
      "Wow, that was quick! I really like concept #2. The minimalist approach is exactly what I was looking for.",
    timestamp: "10:40 AM",
    status: "read",
  },
  {
    id: "msg10",
    sender: "other",
    content: "Great choice! I'll refine concept #2 and send you the final files soon.",
    timestamp: "10:41 AM",
    status: "read",
  },
  {
    id: "msg11",
    sender: "other",
    content:
      "I've completed the final logo design based on concept #2. I've made some refinements to improve scalability and clarity. The files are now ready for download!",
    timestamp: "10:42 AM",
    status: "delivered",
  },
]

