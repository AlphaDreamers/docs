import { Badge } from "@/components/ui/badge"
import { Button } from "@/components/ui/button"
import { Checkbox } from "@/components/ui/checkbox"
import { Label } from "@/components/ui/label"
import { Slider } from "@/components/ui/slider"
import { Accordion, AccordionContent, AccordionItem, AccordionTrigger } from "@/components/ui/accordion"
import { Star } from "lucide-react"

export default function MarketplaceFilters() {
  return (
    <div className="space-y-6">
      <div>
        <h3 className="mb-4 text-lg font-medium">Filters</h3>
        <Button variant="outline" size="sm" className="mb-2 mr-2">
          Clear All
        </Button>
        <div className="flex flex-wrap gap-2">
          <Badge variant="secondary" className="flex items-center gap-1">
            Design
            <button className="ml-1 rounded-full outline-none ring-offset-background focus:ring-2 focus:ring-ring focus:ring-offset-2">
              <X className="h-3 w-3 text-muted-foreground hover:text-foreground" />
              <span className="sr-only">Remove</span>
            </button>
          </Badge>
          <Badge variant="secondary" className="flex items-center gap-1">
            Under $100
            <button className="ml-1 rounded-full outline-none ring-offset-background focus:ring-2 focus:ring-ring focus:ring-offset-2">
              <X className="h-3 w-3 text-muted-foreground hover:text-foreground" />
              <span className="sr-only">Remove</span>
            </button>
          </Badge>
        </div>
      </div>

      <Accordion type="multiple" className="w-full" defaultValue={["category", "price", "rating", "delivery"]}>
        <AccordionItem value="category">
          <AccordionTrigger>Category</AccordionTrigger>
          <AccordionContent>
            <div className="space-y-2">
              <div className="flex items-center space-x-2">
                <Checkbox id="design" />
                <Label htmlFor="design" className="font-normal">
                  Design
                </Label>
              </div>
              <div className="flex items-center space-x-2">
                <Checkbox id="development" />
                <Label htmlFor="development" className="font-normal">
                  Development
                </Label>
              </div>
              <div className="flex items-center space-x-2">
                <Checkbox id="marketing" />
                <Label htmlFor="marketing" className="font-normal">
                  Marketing
                </Label>
              </div>
              <div className="flex items-center space-x-2">
                <Checkbox id="writing" />
                <Label htmlFor="writing" className="font-normal">
                  Writing & Translation
                </Label>
              </div>
              <div className="flex items-center space-x-2">
                <Checkbox id="audio-video" />
                <Label htmlFor="audio-video" className="font-normal">
                  Audio & Video
                </Label>
              </div>
              <div className="flex items-center space-x-2">
                <Checkbox id="business" />
                <Label htmlFor="business" className="font-normal">
                  Business
                </Label>
              </div>
            </div>
          </AccordionContent>
        </AccordionItem>

        <AccordionItem value="price">
          <AccordionTrigger>Price Range</AccordionTrigger>
          <AccordionContent>
            <div className="space-y-4">
              <Slider defaultValue={[0, 1000]} max={1000} step={10} />
              <div className="flex items-center justify-between">
                <div className="flex items-center space-x-2">
                  <Label htmlFor="min-price">Min</Label>
                  <div className="relative">
                    <span className="absolute inset-y-0 left-0 flex items-center pl-2">$</span>
                    <input
                      id="min-price"
                      type="number"
                      className="w-20 rounded-md border pl-6 pr-2 py-1 text-sm"
                      defaultValue={0}
                    />
                  </div>
                </div>
                <div className="flex items-center space-x-2">
                  <Label htmlFor="max-price">Max</Label>
                  <div className="relative">
                    <span className="absolute inset-y-0 left-0 flex items-center pl-2">$</span>
                    <input
                      id="max-price"
                      type="number"
                      className="w-20 rounded-md border pl-6 pr-2 py-1 text-sm"
                      defaultValue={1000}
                    />
                  </div>
                </div>
              </div>
              <Button variant="outline" size="sm" className="w-full">
                Apply
              </Button>
            </div>
          </AccordionContent>
        </AccordionItem>

        <AccordionItem value="rating">
          <AccordionTrigger>Rating</AccordionTrigger>
          <AccordionContent>
            <div className="space-y-2">
              <div className="flex items-center space-x-2">
                <Checkbox id="rating-4plus" />
                <Label htmlFor="rating-4plus" className="flex items-center font-normal">
                  <Star className="h-4 w-4 fill-yellow-400 text-yellow-400" />
                  <Star className="h-4 w-4 fill-yellow-400 text-yellow-400" />
                  <Star className="h-4 w-4 fill-yellow-400 text-yellow-400" />
                  <Star className="h-4 w-4 fill-yellow-400 text-yellow-400" />
                  <Star className="h-4 w-4 text-muted-foreground" />
                  <span className="ml-1 text-sm">& Up</span>
                </Label>
              </div>
              <div className="flex items-center space-x-2">
                <Checkbox id="rating-3plus" />
                <Label htmlFor="rating-3plus" className="flex items-center font-normal">
                  <Star className="h-4 w-4 fill-yellow-400 text-yellow-400" />
                  <Star className="h-4 w-4 fill-yellow-400 text-yellow-400" />
                  <Star className="h-4 w-4 fill-yellow-400 text-yellow-400" />
                  <Star className="h-4 w-4 text-muted-foreground" />
                  <Star className="h-4 w-4 text-muted-foreground" />
                  <span className="ml-1 text-sm">& Up</span>
                </Label>
              </div>
              <div className="flex items-center space-x-2">
                <Checkbox id="rating-2plus" />
                <Label htmlFor="rating-2plus" className="flex items-center font-normal">
                  <Star className="h-4 w-4 fill-yellow-400 text-yellow-400" />
                  <Star className="h-4 w-4 fill-yellow-400 text-yellow-400" />
                  <Star className="h-4 w-4 text-muted-foreground" />
                  <Star className="h-4 w-4 text-muted-foreground" />
                  <Star className="h-4 w-4 text-muted-foreground" />
                  <span className="ml-1 text-sm">& Up</span>
                </Label>
              </div>
            </div>
          </AccordionContent>
        </AccordionItem>

        <AccordionItem value="delivery">
          <AccordionTrigger>Delivery Time</AccordionTrigger>
          <AccordionContent>
            <div className="space-y-2">
              <div className="flex items-center space-x-2">
                <Checkbox id="delivery-24h" />
                <Label htmlFor="delivery-24h" className="font-normal">
                  Express 24h
                </Label>
              </div>
              <div className="flex items-center space-x-2">
                <Checkbox id="delivery-3d" />
                <Label htmlFor="delivery-3d" className="font-normal">
                  Up to 3 days
                </Label>
              </div>
              <div className="flex items-center space-x-2">
                <Checkbox id="delivery-7d" />
                <Label htmlFor="delivery-7d" className="font-normal">
                  Up to 7 days
                </Label>
              </div>
              <div className="flex items-center space-x-2">
                <Checkbox id="delivery-anytime" />
                <Label htmlFor="delivery-anytime" className="font-normal">
                  Anytime
                </Label>
              </div>
            </div>
          </AccordionContent>
        </AccordionItem>

        <AccordionItem value="seller">
          <AccordionTrigger>Seller Details</AccordionTrigger>
          <AccordionContent>
            <div className="space-y-2">
              <div className="flex items-center space-x-2">
                <Checkbox id="top-rated" />
                <Label htmlFor="top-rated" className="font-normal">
                  Top Rated Seller
                </Label>
              </div>
              <div className="flex items-center space-x-2">
                <Checkbox id="blockchain-verified" />
                <Label htmlFor="blockchain-verified" className="font-normal">
                  Blockchain Verified
                </Label>
              </div>
              <div className="flex items-center space-x-2">
                <Checkbox id="offers-customization" />
                <Label htmlFor="offers-customization" className="font-normal">
                  Offers Customization
                </Label>
              </div>
              <div className="flex items-center space-x-2">
                <Checkbox id="online-now" />
                <Label htmlFor="online-now" className="font-normal">
                  Online Now
                </Label>
              </div>
            </div>
          </AccordionContent>
        </AccordionItem>
      </Accordion>
    </div>
  )
}

function X(props) {
  return (
    <svg
      {...props}
      xmlns="http://www.w3.org/2000/svg"
      width="24"
      height="24"
      viewBox="0 0 24 24"
      fill="none"
      stroke="currentColor"
      strokeWidth="2"
      strokeLinecap="round"
      strokeLinejoin="round"
    >
      <path d="M18 6 6 18" />
      <path d="m6 6 12 12" />
    </svg>
  )
}

