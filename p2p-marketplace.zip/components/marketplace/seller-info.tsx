import Link from "next/link"
import Image from "next/image"
import { Button } from "@/components/ui/button"
import { Card, CardContent } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { Bitcoin, CalendarDays, Clock, MessageCircle, Shield, Star } from "lucide-react"

export default function SellerInfo({ seller }) {
  return (
    <Card>
      <CardContent className="p-6">
        <div className="flex flex-col items-center text-center">
          <div className="relative mb-3">
            <div className="relative h-16 w-16 overflow-hidden rounded-full">
              <Image src={seller.avatar || "/placeholder.svg"} alt={seller.name} fill className="object-cover" />
            </div>
            {seller.verifiedSeller && (
              <Badge className="absolute -right-1 -top-1 flex h-6 w-6 items-center justify-center rounded-full bg-emerald-500 p-0">
                <Shield className="h-3 w-3 text-white" />
              </Badge>
            )}
          </div>
          <h3 className="text-lg font-medium">
            <Link href={`/seller/${seller.id}`} className="hover:underline">
              {seller.name}
            </Link>
          </h3>
          <div className="mt-1 flex items-center justify-center">
            <div className="flex items-center">
              <Star className="h-4 w-4 fill-yellow-400 text-yellow-400" />
              <span className="ml-1 font-medium">{seller.rating}</span>
            </div>
          </div>
          <p className="mt-2 text-sm text-muted-foreground">{seller.bio}</p>

          <Button className="mt-4 w-full gap-2">
            <MessageCircle className="h-4 w-4" /> Contact Me
          </Button>
        </div>

        <div className="mt-6 space-y-3 text-sm">
          <div className="flex items-center justify-between">
            <span className="flex items-center gap-1 text-muted-foreground">
              <CalendarDays className="h-4 w-4" /> Member Since
            </span>
            <span>{seller.memberSince}</span>
          </div>
          <div className="flex items-center justify-between">
            <span className="flex items-center gap-1 text-muted-foreground">
              <Clock className="h-4 w-4" /> Response Time
            </span>
            <span>{seller.responseTime}</span>
          </div>
          <div className="flex items-center justify-between">
            <span className="flex items-center gap-1 text-muted-foreground">
              <ShoppingCartIcon className="h-4 w-4" /> Completed Orders
            </span>
            <span>{seller.completedOrders}</span>
          </div>
          <div className="flex items-center justify-between">
            <span className="flex items-center gap-1 text-muted-foreground">
              <Bitcoin className="h-4 w-4" /> Accepts Crypto
            </span>
            <span>USDT</span>
          </div>
        </div>
      </CardContent>
    </Card>
  )
}

function ShoppingCartIcon(props) {
  return (
    <svg
      {...props}
      xmlns="http://www.w3.org/2000/svg"
      width="24"
      height="24"
      viewBox="0 0 24 24"
      fill="none"
      stroke="currentColor"
      strokeWidth="2"
      strokeLinecap="round"
      strokeLinejoin="round"
    >
      <circle cx="8" cy="21" r="1" />
      <circle cx="19" cy="21" r="1" />
      <path d="M2.05 2.05h2l2.66 12.42a2 2 0 0 0 2 1.58h9.78a2 2 0 0 0 1.95-1.57l1.65-7.43H5.12" />
    </svg>
  )
}

