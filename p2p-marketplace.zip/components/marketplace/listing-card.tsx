import Link from "next/link"
import Image from "next/image"
import { Card, CardContent, CardFooter } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { Button } from "@/components/ui/button"
import { Clock, Heart, Shield, ShoppingCart, Star } from "lucide-react"

export default function ListingCard({ listing }) {
  return (
    <Card className="overflow-hidden transition-all hover:shadow-md">
      <Link href={`/marketplace/${listing.id}`} className="block">
        <div className="relative aspect-video overflow-hidden">
          <Badge className="absolute left-2 top-2 z-10">
            {listing.type === "service" ? "Service" : "Digital Asset"}
          </Badge>
          <Image
            src={listing.image || "/placeholder.svg"}
            alt={listing.title}
            fill
            className="object-cover transition-transform hover:scale-105"
          />
        </div>
      </Link>
      <CardContent className="p-4">
        <div className="flex items-center gap-2 text-sm text-muted-foreground">
          <div className="flex items-center gap-1">
            <Star className="h-3 w-3 fill-yellow-400 text-yellow-400" />
            <span>{listing.rating}</span>
          </div>
          <span>({listing.reviewCount})</span>
          {listing.seller.verifiedSeller && (
            <div className="flex items-center gap-1 ml-auto">
              <Shield className="h-3 w-3 text-emerald-500" />
              <span className="text-xs text-emerald-500">Verified</span>
            </div>
          )}
        </div>

        <Link href={`/marketplace/${listing.id}`} className="mt-2 block">
          <h3 className="font-medium line-clamp-1 hover:text-primary">{listing.title}</h3>
        </Link>

        <p className="mt-1 text-sm text-muted-foreground line-clamp-2">{listing.description}</p>

        <div className="mt-3 flex items-center gap-2">
          <Image
            src={listing.seller.avatar || "/placeholder.svg"}
            alt={listing.seller.name}
            width={20}
            height={20}
            className="rounded-full"
          />
          <span className="text-xs text-muted-foreground">{listing.seller.name}</span>
        </div>

        {listing.type === "service" && (
          <div className="mt-2 flex items-center gap-1 text-xs text-muted-foreground">
            <Clock className="h-3 w-3" />
            <span>{listing.deliveryTime}</span>
          </div>
        )}
      </CardContent>
      <CardFooter className="flex items-center justify-between p-4 pt-0">
        <div className="font-bold">${listing.price}</div>
        <div className="flex gap-1">
          <Button variant="ghost" size="icon" className="h-8 w-8 rounded-full">
            <Heart className="h-4 w-4" />
            <span className="sr-only">Add to favorites</span>
          </Button>
          <Button size="sm" className="h-8 gap-1 rounded-full">
            <ShoppingCart className="h-3 w-3" />
            {listing.type === "service" ? "Order" : "Buy"}
          </Button>
        </div>
      </CardFooter>
    </Card>
  )
}

