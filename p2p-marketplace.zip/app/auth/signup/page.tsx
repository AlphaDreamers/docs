import Link from "next/link"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { ChevronRightIcon, ShieldCheckIcon } from "lucide-react"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"

export default function SignupPage() {
  return (
    <div className="container flex items-center justify-center py-10 md:py-16">
      <Card className="mx-auto max-w-4xl">
        <Tabs defaultValue="personal" className="w-full">
          <TabsList className="grid w-full grid-cols-2">
            <TabsTrigger value="personal">Personal Account</TabsTrigger>
            <TabsTrigger value="business">Business Account</TabsTrigger>
          </TabsList>
          <CardHeader>
            <CardTitle className="text-2xl">Create an Account</CardTitle>
            <CardDescription>
              Join our secure marketplace with blockchain verification and start buying or selling.
            </CardDescription>
          </CardHeader>
          <CardContent>
            <TabsContent value="personal" className="mt-0">
              <form>
                <div className="grid gap-6">
                  <div className="grid gap-3">
                    <div className="grid grid-cols-2 gap-4">
                      <div className="space-y-2">
                        <Label htmlFor="first-name">First name</Label>
                        <Input id="first-name" placeholder="Enter your first name" required />
                      </div>
                      <div className="space-y-2">
                        <Label htmlFor="last-name">Last name</Label>
                        <Input id="last-name" placeholder="Enter your last name" required />
                      </div>
                    </div>
                    <div className="space-y-2">
                      <Label htmlFor="email">Email</Label>
                      <Input id="email" type="email" placeholder="name@example.com" required />
                    </div>
                    <div className="space-y-2">
                      <Label htmlFor="password">Password</Label>
                      <Input id="password" type="password" required />
                    </div>
                    <div className="space-y-2">
                      <Label htmlFor="confirm-password">Confirm Password</Label>
                      <Input id="confirm-password" type="password" required />
                    </div>
                    <div className="space-y-2">
                      <Label htmlFor="country">Country</Label>
                      <Select>
                        <SelectTrigger id="country">
                          <SelectValue placeholder="Select your country" />
                        </SelectTrigger>
                        <SelectContent>
                          <SelectItem value="us">United States</SelectItem>
                          <SelectItem value="ca">Canada</SelectItem>
                          <SelectItem value="uk">United Kingdom</SelectItem>
                          <SelectItem value="au">Australia</SelectItem>
                          <SelectItem value="jp">Japan</SelectItem>
                          <SelectItem value="fr">France</SelectItem>
                          <SelectItem value="de">Germany</SelectItem>
                        </SelectContent>
                      </Select>
                    </div>
                  </div>

                  <div className="space-y-4">
                    <div className="flex items-start gap-4 rounded-lg border p-4">
                      <div className="flex h-10 w-10 shrink-0 items-center justify-center rounded-full bg-primary/10">
                        <ShieldCheckIcon className="h-5 w-5 text-primary" />
                      </div>
                      <div className="space-y-1">
                        <p className="text-sm font-medium">KYC Verification Required</p>
                        <p className="text-sm text-muted-foreground">
                          To ensure security and trust in our marketplace, we require all users to complete a KYC
                          verification process. This will be required before you can make transactions.
                        </p>
                      </div>
                    </div>

                    <div className="flex items-start gap-4 rounded-lg border p-4">
                      <div className="flex h-10 w-10 shrink-0 items-center justify-center rounded-full bg-primary/10">
                        <ShieldCheckIcon className="h-5 w-5 text-primary" />
                      </div>
                      <div className="space-y-1">
                        <p className="text-sm font-medium">Blockchain Integration</p>
                        <p className="text-sm text-muted-foreground">
                          Our platform uses blockchain to verify transactions and reviews, ensuring transparency and
                          building trust. Your data remains secure and actions are verifiable.
                        </p>
                      </div>
                    </div>
                  </div>
                </div>
              </form>
            </TabsContent>

            <TabsContent value="business" className="mt-0">
              <form>
                <div className="grid gap-6">
                  <div className="grid gap-3">
                    <div className="space-y-2">
                      <Label htmlFor="business-name">Business name</Label>
                      <Input id="business-name" placeholder="Enter your business name" required />
                    </div>
                    <div className="space-y-2">
                      <Label htmlFor="business-email">Business email</Label>
                      <Input id="business-email" type="email" placeholder="business@example.com" required />
                    </div>
                    <div className="space-y-2">
                      <Label htmlFor="business-type">Business type</Label>
                      <Select>
                        <SelectTrigger id="business-type">
                          <SelectValue placeholder="Select your business type" />
                        </SelectTrigger>
                        <SelectContent>
                          <SelectItem value="soleProprietor">Sole Proprietor</SelectItem>
                          <SelectItem value="llc">LLC</SelectItem>
                          <SelectItem value="corporation">Corporation</SelectItem>
                          <SelectItem value="partnership">Partnership</SelectItem>
                          <SelectItem value="nonprofit">Non-profit</SelectItem>
                        </SelectContent>
                      </Select>
                    </div>
                    <div className="space-y-2">
                      <Label htmlFor="business-password">Password</Label>
                      <Input id="business-password" type="password" required />
                    </div>
                    <div className="space-y-2">
                      <Label htmlFor="business-confirm-password">Confirm Password</Label>
                      <Input id="business-confirm-password" type="password" required />
                    </div>
                    <div className="space-y-2">
                      <Label htmlFor="business-country">Country</Label>
                      <Select>
                        <SelectTrigger id="business-country">
                          <SelectValue placeholder="Select country of registration" />
                        </SelectTrigger>
                        <SelectContent>
                          <SelectItem value="us">United States</SelectItem>
                          <SelectItem value="ca">Canada</SelectItem>
                          <SelectItem value="uk">United Kingdom</SelectItem>
                          <SelectItem value="au">Australia</SelectItem>
                          <SelectItem value="jp">Japan</SelectItem>
                          <SelectItem value="fr">France</SelectItem>
                          <SelectItem value="de">Germany</SelectItem>
                        </SelectContent>
                      </Select>
                    </div>
                  </div>

                  <div className="space-y-4">
                    <div className="flex items-start gap-4 rounded-lg border p-4">
                      <div className="flex h-10 w-10 shrink-0 items-center justify-center rounded-full bg-primary/10">
                        <ShieldCheckIcon className="h-5 w-5 text-primary" />
                      </div>
                      <div className="space-y-1">
                        <p className="text-sm font-medium">Business Verification Required</p>
                        <p className="text-sm text-muted-foreground">
                          Business accounts require additional verification including business registration documents.
                          This helps ensure legitimacy and trust for all marketplace participants.
                        </p>
                      </div>
                    </div>

                    <div className="flex items-start gap-4 rounded-lg border p-4">
                      <div className="flex h-10 w-10 shrink-0 items-center justify-center rounded-full bg-primary/10">
                        <ShieldCheckIcon className="h-5 w-5 text-primary" />
                      </div>
                      <div className="space-y-1">
                        <p className="text-sm font-medium">Enhanced Seller Features</p>
                        <p className="text-sm text-muted-foreground">
                          Business accounts get access to advanced analytics, bulk listing tools, and special visibility
                          on the marketplace.
                        </p>
                      </div>
                    </div>
                  </div>
                </div>
              </form>
            </TabsContent>
          </CardContent>
          <CardFooter className="flex flex-col space-y-4">
            <div className="w-full">
              <Button className="w-full" size="lg">
                Create Account
                <ChevronRightIcon className="ml-2 h-4 w-4" />
              </Button>
            </div>
            <div className="text-center text-sm">
              Already have an account?{" "}
              <Link href="/auth/login" className="underline underline-offset-4 hover:text-primary">
                Sign in
              </Link>
            </div>
            <div className="text-center text-xs text-muted-foreground">
              By creating an account, you agree to our{" "}
              <Link href="/terms" className="underline underline-offset-4 hover:text-primary">
                Terms of Service
              </Link>{" "}
              and{" "}
              <Link href="/privacy" className="underline underline-offset-4 hover:text-primary">
                Privacy Policy
              </Link>
            </div>
          </CardFooter>
        </Tabs>
      </Card>
    </div>
  )
}

