"use client"

import { useState } from "react"
import { Button } from "@/components/ui/button"
import { ArrowLeftRight, CheckCircle2, ChevronDown, ChevronUp, Clock, FileCheck, Shield } from "lucide-react"

export default function TransactionFlow() {
  const [expanded, setExpanded] = useState(false)

  return (
    <div className="space-y-4">
      <div className="relative">
        <div className="absolute left-6 top-0 h-full w-0.5 bg-muted-foreground/20"></div>

        {flowSteps.slice(0, expanded ? flowSteps.length : 3).map((step, index) => (
          <div key={index} className="relative flex gap-4 pb-8 last:pb-0">
            <div
              className={`z-10 flex h-12 w-12 shrink-0 items-center justify-center rounded-full border ${step.completed ? "bg-primary text-primary-foreground" : "bg-muted"}`}
            >
              <step.icon className="h-5 w-5" />
            </div>

            <div className="flex flex-col pt-1">
              <h4 className="font-medium">{step.title}</h4>
              <p className="text-sm text-muted-foreground">{step.description}</p>

              {step.details && (
                <div className="mt-2 rounded-lg bg-muted/50 p-3">
                  <div className="grid gap-2 text-sm">
                    {Object.entries(step.details).map(([key, value]) => (
                      <div key={key} className="flex items-center justify-between">
                        <span className="text-muted-foreground">{key}:</span>
                        <span className="font-medium">{value}</span>
                      </div>
                    ))}
                  </div>
                </div>
              )}
            </div>
          </div>
        ))}
      </div>

      {flowSteps.length > 3 && (
        <Button variant="ghost" className="w-full" onClick={() => setExpanded(!expanded)}>
          {expanded ? (
            <>
              <ChevronUp className="mr-2 h-4 w-4" />
              Show Less
            </>
          ) : (
            <>
              <ChevronDown className="mr-2 h-4 w-4" />
              Show More
            </>
          )}
        </Button>
      )}
    </div>
  )
}

const flowSteps = [
  {
    title: "Order Initiated",
    description: "Buyer Emma Watson placed an order for Professional Logo Design",
    completed: true,
    icon: Clock,
    details: {
      Timestamp: "Aug 15, 2023, 10:15:22 AM",
      "Order ID": "ORD-12345",
      Amount: "$120.00",
    },
  },
  {
    title: "Payment to Escrow",
    description: "Payment transferred to escrow account",
    completed: true,
    icon: ArrowLeftRight,
    details: {
      Timestamp: "Aug 15, 2023, 10:15:45 AM",
      "Transaction Hash": "0x5d4c3b...2a1b9c",
      Status: "Confirmed",
    },
  },
  {
    title: "Work Delivered",
    description: "Seller Alex Morgan delivered the completed logo design files",
    completed: true,
    icon: FileCheck,
    details: {
      Timestamp: "Aug 15, 2023, 2:10:30 PM",
      Deliverables: "logo_final.ai, logo_final.png",
      "File Hashes": "Verified",
    },
  },
  {
    title: "Buyer Approval",
    description: "Buyer confirmed satisfaction with the delivered work",
    completed: true,
    icon: CheckCircle2,
    details: {
      Timestamp: "Aug 15, 2023, 2:20:15 PM",
      "Approval Note": "Exactly what I wanted, thank you!",
    },
  },
  {
    title: "Payment Released",
    description: "Payment released from escrow to seller's account",
    completed: true,
    icon: ArrowLeftRight,
    details: {
      Timestamp: "Aug 15, 2023, 2:23:45 PM",
      "Transaction Hash": "0x7ae92b4c6e8d9f0a1b2c3d4e5f6a7b8c9d0e1f2a",
      Amount: "$120.00",
    },
  },
  {
    title: "Transaction Verified",
    description: "Transaction verified and recorded on blockchain",
    completed: true,
    icon: Shield,
    details: {
      "Block Number": "14,356,789",
      Confirmations: "1,245",
      Finality: "100%",
    },
  },
]

