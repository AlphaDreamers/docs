import Link from "next/link"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import {
  ArrowLeftRight,
  CheckCircle2,
  ChevronRight,
  Copy,
  ExternalLink,
  FileText,
  Search,
  Shield,
  Tag,
  User,
} from "lucide-react"
import BlockchainStats from "@/components/blockchain/blockchain-stats"
import TransactionsList from "@/components/blockchain/transactions-list"
import TransactionFlow from "@/components/blockchain/transaction-flow"

export default function BlockchainScannerPage() {
  return (
    <div className="container px-4 py-8 md:px-6 md:py-10">
      <div className="mb-8 space-y-4">
        <h1 className="text-3xl font-bold tracking-tight">Blockchain Scanner</h1>
        <p className="text-muted-foreground">
          Verify marketplace transactions, reviews, and user activities on the blockchain
        </p>

        <div className="flex flex-col gap-4 sm:flex-row">
          <div className="relative flex-1">
            <Search className="absolute left-2.5 top-2.5 h-4 w-4 text-muted-foreground" />
            <Input type="search" placeholder="Search by transaction hash, block, account..." className="pl-8" />
          </div>
          <Button>
            <Search className="mr-2 h-4 w-4" />
            Search
          </Button>
        </div>
      </div>

      <BlockchainStats />

      <div className="mt-8 grid gap-6 md:grid-cols-3">
        <Card className="md:col-span-2">
          <CardHeader className="pb-3">
            <CardTitle>Recent Transactions</CardTitle>
            <CardDescription>Latest verified marketplace activities on the blockchain</CardDescription>
          </CardHeader>
          <CardContent>
            <TransactionsList />
            <div className="mt-4 text-center">
              <Button variant="outline" asChild>
                <Link href="/blockchain/scanner/transactions">
                  View All Transactions
                  <ChevronRight className="ml-1 h-4 w-4" />
                </Link>
              </Button>
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="pb-3">
            <CardTitle>Transaction Types</CardTitle>
            <CardDescription>Breakdown of marketplace activities</CardDescription>
          </CardHeader>
          <CardContent>
            <div className="space-y-4">
              {transactionTypes.map((type) => (
                <div key={type.name} className="flex items-center justify-between">
                  <div className="flex items-center gap-2">
                    <div className={`rounded-full p-1.5 ${type.bgColor}`}>
                      <type.icon className={`h-4 w-4 ${type.iconColor}`} />
                    </div>
                    <span className="text-sm font-medium">{type.name}</span>
                  </div>
                  <Badge variant="outline">{type.count}</Badge>
                </div>
              ))}

              <div className="pt-4">
                <Button variant="outline" className="w-full" asChild>
                  <Link href="/blockchain/scanner/analytics">View Analytics</Link>
                </Button>
              </div>
            </div>
          </CardContent>
        </Card>
      </div>

      <div className="mt-8">
        <Card>
          <CardHeader>
            <CardTitle>Transaction Details</CardTitle>
            <CardDescription>Example of a verified marketplace transaction</CardDescription>
          </CardHeader>
          <CardContent>
            <Tabs defaultValue="overview">
              <TabsList className="mb-4">
                <TabsTrigger value="overview">Overview</TabsTrigger>
                <TabsTrigger value="data">Transaction Data</TabsTrigger>
                <TabsTrigger value="logs">Logs</TabsTrigger>
              </TabsList>

              <TabsContent value="overview" className="space-y-6">
                <div className="rounded-lg border p-4">
                  <div className="flex flex-col justify-between gap-4 md:flex-row md:items-center">
                    <div>
                      <div className="flex items-center gap-2">
                        <Badge className="bg-emerald-500">Success</Badge>
                        <h3 className="text-lg font-medium">Order Completion</h3>
                      </div>
                      <p className="mt-1 text-sm text-muted-foreground">
                        Transaction Hash: 0x7ae92b4c6e8d9f0a1b2c3d4e5f6a7b8c9d0e1f2a
                      </p>
                    </div>
                    <div className="flex flex-wrap gap-2">
                      <Button variant="outline" size="sm" className="h-8 gap-1">
                        <Copy className="h-3 w-3" />
                        <span className="text-xs">Copy Hash</span>
                      </Button>
                      <Button variant="outline" size="sm" className="h-8 gap-1">
                        <ExternalLink className="h-3 w-3" />
                        <span className="text-xs">View Raw</span>
                      </Button>
                    </div>
                  </div>
                </div>

                <div className="grid gap-4 md:grid-cols-2">
                  <div className="space-y-4">
                    <div className="rounded-lg border p-4">
                      <h4 className="mb-3 text-sm font-medium text-muted-foreground">Transaction Info</h4>
                      <div className="space-y-3">
                        <div className="flex justify-between">
                          <span className="text-sm text-muted-foreground">Status:</span>
                          <div className="flex items-center gap-1 text-emerald-500">
                            <CheckCircle2 className="h-4 w-4" />
                            <span className="text-sm font-medium">Confirmed</span>
                          </div>
                        </div>
                        <div className="flex justify-between">
                          <span className="text-sm text-muted-foreground">Block:</span>
                          <Link
                            href="/blockchain/scanner/block/14356789"
                            className="text-sm font-medium hover:underline"
                          >
                            14,356,789
                          </Link>
                        </div>
                        <div className="flex justify-between">
                          <span className="text-sm text-muted-foreground">Timestamp:</span>
                          <span className="text-sm">Aug 15, 2023, 2:23:45 PM</span>
                        </div>
                        <div className="flex justify-between">
                          <span className="text-sm text-muted-foreground">Transaction Fee:</span>
                          <span className="text-sm">0.000042 ETH</span>
                        </div>
                        <div className="flex justify-between">
                          <span className="text-sm text-muted-foreground">Gas Used:</span>
                          <span className="text-sm">125,000 (75%)</span>
                        </div>
                      </div>
                    </div>

                    <div className="rounded-lg border p-4">
                      <h4 className="mb-3 text-sm font-medium text-muted-foreground">Marketplace Info</h4>
                      <div className="space-y-3">
                        <div className="flex justify-between">
                          <span className="text-sm text-muted-foreground">Activity Type:</span>
                          <Badge>Order Completion</Badge>
                        </div>
                        <div className="flex justify-between">
                          <span className="text-sm text-muted-foreground">Order ID:</span>
                          <Link href="/orders/ORD-12345" className="text-sm font-medium hover:underline">
                            ORD-12345
                          </Link>
                        </div>
                        <div className="flex justify-between">
                          <span className="text-sm text-muted-foreground">Listing:</span>
                          <Link href="/marketplace/1" className="text-sm font-medium hover:underline">
                            Professional Logo Design
                          </Link>
                        </div>
                        <div className="flex justify-between">
                          <span className="text-sm text-muted-foreground">Amount:</span>
                          <span className="text-sm font-medium">$120.00</span>
                        </div>
                      </div>
                    </div>
                  </div>

                  <div className="space-y-4">
                    <div className="rounded-lg border p-4">
                      <h4 className="mb-3 text-sm font-medium text-muted-foreground">Participants</h4>
                      <div className="space-y-4">
                        <div>
                          <div className="flex items-center justify-between">
                            <span className="text-sm text-muted-foreground">Seller:</span>
                            <Link
                              href="/seller/seller1"
                              className="flex items-center gap-1 text-sm font-medium hover:underline"
                            >
                              <User className="h-3 w-3" />
                              Alex Morgan
                            </Link>
                          </div>
                          <div className="mt-1 flex items-center justify-between">
                            <span className="text-sm text-muted-foreground">Wallet:</span>
                            <span className="text-xs font-mono">0x1a2b3c...7e8f9g</span>
                          </div>
                        </div>

                        <div>
                          <div className="flex items-center justify-between">
                            <span className="text-sm text-muted-foreground">Buyer:</span>
                            <Link
                              href="/user/user1"
                              className="flex items-center gap-1 text-sm font-medium hover:underline"
                            >
                              <User className="h-3 w-3" />
                              Emma Watson
                            </Link>
                          </div>
                          <div className="mt-1 flex items-center justify-between">
                            <span className="text-sm text-muted-foreground">Wallet:</span>
                            <span className="text-xs font-mono">0x9g8f7e...3c2b1a</span>
                          </div>
                        </div>

                        <div>
                          <div className="flex items-center justify-between">
                            <span className="text-sm text-muted-foreground">Escrow:</span>
                            <span className="text-xs font-mono">0x5d4c3b...2a1b9c</span>
                          </div>
                        </div>
                      </div>
                    </div>

                    <div className="rounded-lg border p-4">
                      <h4 className="mb-3 text-sm font-medium text-muted-foreground">Verification</h4>
                      <div className="space-y-3">
                        <div className="flex items-center justify-between">
                          <span className="text-sm text-muted-foreground">Status:</span>
                          <div className="flex items-center gap-1 text-emerald-500">
                            <Shield className="h-4 w-4" />
                            <span className="text-sm font-medium">Verified</span>
                          </div>
                        </div>
                        <div className="flex items-center justify-between">
                          <span className="text-sm text-muted-foreground">Confirmations:</span>
                          <span className="text-sm">1,245</span>
                        </div>
                        <div className="flex items-center justify-between">
                          <span className="text-sm text-muted-foreground">Finality:</span>
                          <span className="text-sm">100%</span>
                        </div>
                      </div>

                      <div className="mt-4">
                        <Button variant="outline" size="sm" className="w-full gap-1">
                          <Shield className="h-3 w-3" />
                          <span className="text-xs">Verify Authenticity</span>
                        </Button>
                      </div>
                    </div>
                  </div>
                </div>

                <div className="rounded-lg border p-4">
                  <h4 className="mb-4 text-sm font-medium text-muted-foreground">Transaction Flow</h4>
                  <TransactionFlow />
                </div>
              </TabsContent>

              <TabsContent value="data">
                <div className="rounded-lg border p-4">
                  <div className="flex items-center justify-between">
                    <h4 className="text-sm font-medium">Raw Transaction Data</h4>
                    <Button variant="outline" size="sm">
                      <Copy className="mr-2 h-3 w-3" />
                      Copy Raw Data
                    </Button>
                  </div>
                  <pre className="mt-4 overflow-auto rounded-lg bg-muted p-4 text-xs font-mono">
                    {`{
  "hash": "0x7ae92b4c6e8d9f0a1b2c3d4e5f6a7b8c9d0e1f2a",
  "blockNumber": 14356789,
  "timestamp": "2023-08-15T14:23:45Z",
  "from": "0x1a2b3c4d5e6f7g8h9i0j1k2l3m4n5o6p7q8r9s",
  "to": "0x9s8r7q6p5o4n3m2l1k0j9i8h7g6f5e4d3c2b1a",
  "value": "0",
  "gasPrice": "20000000000",
  "gasLimit": "21000",
  "gasUsed": "125000",
  "nonce": 42,
  "input": "0x7b22616374696f6e223a22636f6d706c6574654f72646572222c226f7264657249...",
  "marketplaceData": {
    "action": "completeOrder",
    "orderId": "ORD-12345",
    "listingId": "1",
    "sellerId": "seller1",
    "buyerId": "user1",
    "amount": "120.00",
    "currency": "USD",
    "timestamp": "2023-08-15T14:23:45Z",
    "status": "completed",
    "deliverables": [
      {
        "type": "file",
        "name": "logo_final.ai",
        "hash": "0x8f7e6d5c4b3a2918d7c6b5a4938271605f4e3d2c1b0a"
      },
      {
        "type": "file",
        "name": "logo_final.png",
        "hash": "0x1a2b3c4d5e6f7g8h9i0j1k2l3m4n5o6p7q8r9s"
      }
    ]
  }
}`}
                  </pre>
                </div>
              </TabsContent>

              <TabsContent value="logs">
                <div className="rounded-lg border p-4">
                  <h4 className="mb-4 text-sm font-medium">Event Logs</h4>
                  <div className="space-y-4">
                    {transactionLogs.map((log, index) => (
                      <div key={index} className="rounded-lg bg-muted p-3">
                        <div className="flex items-center gap-2">
                          <Badge
                            variant={
                              log.type === "info" ? "secondary" : log.type === "success" ? "default" : "destructive"
                            }
                          >
                            {log.type}
                          </Badge>
                          <span className="text-xs font-medium">{log.event}</span>
                          <span className="text-xs text-muted-foreground">{log.timestamp}</span>
                        </div>
                        <p className="mt-2 text-xs">{log.message}</p>
                        {log.data && (
                          <pre className="mt-2 overflow-auto rounded bg-background p-2 text-xs font-mono">
                            {JSON.stringify(log.data, null, 2)}
                          </pre>
                        )}
                      </div>
                    ))}
                  </div>
                </div>
              </TabsContent>
            </Tabs>
          </CardContent>
        </Card>
      </div>
    </div>
  )
}

const transactionTypes = [
  {
    name: "Order Completion",
    count: 1245,
    icon: CheckCircle2,
    bgColor: "bg-emerald-100 dark:bg-emerald-900/20",
    iconColor: "text-emerald-500",
  },
  {
    name: "Review Submission",
    count: 876,
    icon: FileText,
    bgColor: "bg-blue-100 dark:bg-blue-900/20",
    iconColor: "text-blue-500",
  },
  {
    name: "Payment Processing",
    count: 2134,
    icon: ArrowLeftRight,
    bgColor: "bg-purple-100 dark:bg-purple-900/20",
    iconColor: "text-purple-500",
  },
  {
    name: "Listing Creation",
    count: 543,
    icon: Tag,
    bgColor: "bg-orange-100 dark:bg-orange-900/20",
    iconColor: "text-orange-500",
  },
  {
    name: "User Verification",
    count: 321,
    icon: Shield,
    bgColor: "bg-cyan-100 dark:bg-cyan-900/20",
    iconColor: "text-cyan-500",
  },
]

const transactionLogs = [
  {
    type: "info",
    event: "TransactionInitiated",
    timestamp: "14:23:40",
    message: "Order completion transaction initiated by seller",
    data: {
      sellerId: "seller1",
      orderId: "ORD-12345",
    },
  },
  {
    type: "info",
    event: "EscrowReleaseRequested",
    timestamp: "14:23:42",
    message: "Escrow release requested for completed order",
  },
  {
    type: "info",
    event: "DeliverableVerification",
    timestamp: "14:23:43",
    message: "Verifying deliverable file hashes",
    data: {
      files: ["logo_final.ai", "logo_final.png"],
    },
  },
  {
    type: "success",
    event: "PaymentReleased",
    timestamp: "14:23:44",
    message: "Payment released from escrow to seller",
    data: {
      amount: "120.00",
      currency: "USD",
    },
  },
  {
    type: "success",
    event: "TransactionCompleted",
    timestamp: "14:23:45",
    message: "Order completion transaction confirmed on blockchain",
  },
]

