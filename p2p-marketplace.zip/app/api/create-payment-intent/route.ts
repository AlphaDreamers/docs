import { NextResponse } from "next/server"
import Stripe from "stripe"

// This would be your actual Stripe secret key in a real app
// For this prototype, we're using a placeholder
const stripe = new Stripe("sk_test_placeholder", {
  apiVersion: "2023-10-16",
})

export async function POST(req: Request) {
  try {
    const { amount, listingId, sellerId } = await req.json()

    // In a real implementation, you would:
    // 1. Verify the listing exists and is available
    // 2. Check that the price matches what's in your database
    // 3. Set up Stripe Connect to pay the seller directly

    // Create a PaymentIntent with the order amount and currency
    const paymentIntent = await stripe.paymentIntents.create({
      amount: amount * 100, // Stripe expects amounts in cents
      currency: "usd",
      // In a real app with Stripe Connect, you would include:
      // transfer_data: {
      //   destination: sellerStripeAccountId,
      // },
      metadata: {
        listingId,
        sellerId,
      },
    })

    return NextResponse.json({
      clientSecret: paymentIntent.client_secret,
    })
  } catch (error) {
    console.error("Error creating payment intent:", error)
    return NextResponse.json({ error: "Failed to create payment intent" }, { status: 500 })
  }
}

